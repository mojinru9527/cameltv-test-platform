"""AIQE adapters。"""
