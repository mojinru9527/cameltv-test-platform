"""UI test API routes."""
from __future__ import annotations

import logging
from datetime import datetime, timezone

from pathlib import Path as _Path

logger = logging.getLogger(__name__)

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.deps import CurrentUser, get_db, require_permission
from app.schemas.common import R
from app.schemas.ui_test import (
    UiTestJobCreate,
    UiTestJobDetailOut,
    UiTestJobOut,
    UiTestJobUpdate,
    UiTestRunOut,
    UiTestTriggerRequest,
)
from app.services import ui_test_service
from app.services.audit_service import write_audit

from app.core.execution_dispatch import ExecutionRoute

router = APIRouter(prefix="/ui-tests", tags=["UI 自动化"], route_class=ExecutionRoute)


def _audit(req: Request, cu: CurrentUser, db: Session, action: str, target: str, detail: str = ""):
    write_audit(
        db, user_id=cu.user.id, username=cu.user.username or "",
        project_id=cu.project_id or 0, action=action, target=target, detail=detail,
        ip=req.client.host if req.client else "",
    )


def _get_project_run(db: Session, run_id: int, project_id: int):
    """Load a run only through its owning job and current project."""
    return ui_test_service.get_project_run(db, run_id, project_id)


def _resolve_artifact_path(artifact_dir: _Path, filename: str) -> _Path:
    """Resolve one artifact path without string-prefix containment mistakes."""
    base_dir = artifact_dir.resolve()
    file_path = (base_dir / filename).resolve()
    if not file_path.is_relative_to(base_dir):
        raise HTTPException(403, "非法文件路径")
    return file_path


# ═══════════════════════════════════════════════════════
# 静态路径路由（必须在 /{job_id} 之前注册，避免被动态段误匹配）
# ═══════════════════════════════════════════════════════

@router.get("", response_model=R[dict])
def list_jobs(
    status: str | None = Query(None),
    keyword: str = Query(""),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    current: CurrentUser = Depends(require_permission("uitest:list")),
    db: Session = Depends(get_db),
):
    items, total = ui_test_service.list_jobs(
        db, project_id=current.project_id or 0,
        status=status, keyword=keyword, page=page, page_size=page_size,
    )
    return R.ok({"total": total, "page": page, "page_size": page_size, "items": items})


@router.post("", response_model=R[UiTestJobOut])
def create_job(
    req: Request, body: UiTestJobCreate,
    current: CurrentUser = Depends(require_permission("uitest:code_execute")),
    db: Session = Depends(get_db),
):
    r = ui_test_service.create_job(db, body, current.user.id, current.project_id or 0)
    db.commit()
    _audit(req, current, db, "uitest:create", f"#{r['id']} {r['name']}")
    return R.ok(UiTestJobOut(**r))


class FromCasesRequest(BaseModel):
    case_ids: list[int] = []


@router.post("/jobs/from-cases", response_model=R[dict], summary="从用例批量创建 UI 任务（C151-1）")
def create_jobs_from_cases(
    body: FromCasesRequest,
    req: Request,
    current: CurrentUser = Depends(require_permission("uitest:create")),
    db: Session = Depends(get_db),
):
    try:
        result = ui_test_service.create_jobs_from_cases(
            db,
            project_id=current.project_id or 0,
            case_ids=body.case_ids,
            creator_id=current.user.id,
        )
    except ValueError as e:
        return R(code=1, msg=str(e))
    _audit(req, current, db, "uitest:jobs_from_cases", f"project#{current.project_id or 0}", f"created={result['created']}")
    return R.ok(result)


@router.get("/scripts", response_model=R[dict], summary="脚本资产列表")
def list_script_assets(
    current: CurrentUser = Depends(require_permission("uitest:list")),
    db: Session = Depends(get_db),
):
    """返回脚本资产 + 文件系统中可用的 Playwright 脚本。"""
    assets = ui_test_service.list_script_assets(db, current.project_id or 0)
    specs = ui_test_service.list_available_specs()
    return R.ok({"assets": assets, "available_specs": specs})


@router.post("/scripts", response_model=R[dict], summary="创建脚本资产")
def create_script_asset(
    req: Request, body,
    current: CurrentUser = Depends(require_permission("uitest:create")),
    db: Session = Depends(get_db),
):
    from app.schemas.ui_test import UiTestScriptCreate as C
    body = C.model_validate(body if isinstance(body, dict) else body.model_dump())
    r = ui_test_service.create_script_asset(db, body, current.project_id or 0)
    db.commit()
    _audit(req, current, db, "uitest:script_create", f"#{r['id']} {r['name']}")
    return R.ok(r)


@router.get("/scripts/{script_id}", response_model=R[dict], summary="脚本资产详情")
def get_script_asset(
    script_id: int,
    current: CurrentUser = Depends(require_permission("uitest:detail")),
    db: Session = Depends(get_db),
):
    r = ui_test_service.get_script_asset(db, script_id, current.project_id or 0)
    if not r:
        raise HTTPException(404, "脚本资产不存在")
    return R.ok(r)


@router.put("/scripts/{script_id}", response_model=R[dict], summary="更新脚本资产")
def update_script_asset(
    req: Request, script_id: int, body,
    current: CurrentUser = Depends(require_permission("uitest:update")),
    db: Session = Depends(get_db),
):
    from app.schemas.ui_test import UiTestScriptUpdate as U
    body = U.model_validate(body if isinstance(body, dict) else body.model_dump())
    r = ui_test_service.update_script_asset(db, script_id, body, current.project_id or 0)
    if not r:
        raise HTTPException(404, "脚本资产不存在")
    db.commit()
    _audit(req, current, db, "uitest:script_update", f"#{script_id}")
    return R.ok(r)


@router.delete("/scripts/{script_id}", response_model=R[dict], summary="删除脚本资产")
def delete_script_asset(
    req: Request, script_id: int,
    current: CurrentUser = Depends(require_permission("uitest:delete")),
    db: Session = Depends(get_db),
):
    ok = ui_test_service.delete_script_asset(db, script_id, current.project_id or 0)
    if not ok:
        raise HTTPException(404, "脚本资产不存在")
    db.commit()
    _audit(req, current, db, "uitest:script_delete", f"#{script_id}")
    return R.ok({"deleted": True})


@router.get("/runs/{run_id}", response_model=R[UiTestRunOut], summary="获取运行记录详情")
def get_run(
    run_id: int,
    current: CurrentUser = Depends(require_permission("uitest:detail")),
    db: Session = Depends(get_db),
):
    """查询单次运行记录（用于前端轮询状态），校验项目归属。"""
    run = ui_test_service.get_run(db, run_id, current.project_id or 0)
    if not run:
        from app.core.exceptions import not_found
        raise not_found("运行记录")
    return R.ok(UiTestRunOut(**run))


@router.post("/runs/{run_id}/cancel", response_model=R[dict], summary="取消运行中的 UI 测试")
def cancel_run(
    req: Request, run_id: int,
    current: CurrentUser = Depends(require_permission("uitest:trigger")),
    db: Session = Depends(get_db),
):
    """取消正在运行的 UI 测试。设置 cancel_requested 标志，运行中 worker 会检测并终止进程。"""
    run = ui_test_service.get_run_orm(db, run_id)
    if not run:
        raise HTTPException(404, "运行记录不存在")
    # Verify project isolation
    job = ui_test_service.get_job_orm(db, run.job_id)
    if not job or job.project_id != (current.project_id or 0):
        raise HTTPException(404, "运行记录不存在")
    if run.status not in ("pending", "running"):
        raise HTTPException(400, f"只能取消 pending/running 状态的运行（当前: {run.status}）")
    # Set cancel flag so worker can detect and kill subprocess
    run.cancel_requested = True
    run.status = "cancelled"
    run.finished_at = datetime.now(timezone.utc)
    run.error_message = "用户手动取消"
    # Update job status too
    if job.status == "running":
        job.status = "pending"
    db.commit()
    _audit(req, current, db, "uitest:cancel", f"run #{run_id}")
    return R.ok({"status": "cancelled", "run_id": run_id})


@router.get("/runs/{run_id}/artifacts", response_model=R[list[dict]], summary="运行产物列表")
def list_artifacts(
    run_id: int,
    current: CurrentUser = Depends(require_permission("uitest:detail")),
    db: Session = Depends(get_db),
):
    """列出某次运行的所有产物文件（截图/视频/trace/报告）。"""
    run = _get_project_run(db, run_id, current.project_id or 0)
    if not run:
        raise HTTPException(404, "运行记录不存在")

    artifact_dir = _Path(run.artifact_dir).resolve() if run.artifact_dir else None
    if not artifact_dir or not artifact_dir.exists():
        return R.ok([])

    files = []
    for f in sorted(artifact_dir.rglob("*")):
        if f.is_file():
            rel = str(f.relative_to(artifact_dir)).replace("\\", "/")
            files.append({
                "name": f.name,
                "path": rel,
                "size_bytes": f.stat().st_size,
                "type": f.suffix.lstrip("."),
            })
    return R.ok(files)


@router.get("/runs/{run_id}/artifacts/{filename:path}", summary="下载运行产物")
def download_artifact(
    run_id: int,
    filename: str,
    current: CurrentUser = Depends(require_permission("uitest:detail")),
    db: Session = Depends(get_db),
):
    """下载某次运行的产物文件。"""
    run = _get_project_run(db, run_id, current.project_id or 0)
    if not run:
        raise HTTPException(404, "运行记录不存在")

    artifact_dir = _Path(run.artifact_dir) if run.artifact_dir else None
    if not artifact_dir:
        raise HTTPException(404, "该运行无产物目录")

    file_path = _resolve_artifact_path(artifact_dir, filename)

    if not file_path.exists() or not file_path.is_file():
        raise HTTPException(404, "产物文件不存在")

    return FileResponse(file_path, filename=file_path.name)


@router.post(
    "/capture", response_model=R[dict], summary="创建页面 XHR 采集任务（C115-3）",
    responses={429: {"description": "Browser capacity busy; retry after Retry-After seconds",
                     "headers": {"Retry-After": {"schema": {"type": "string"}}}}},
)
def create_capture(
    body: dict,
    current: CurrentUser = Depends(require_permission("uitest:trigger")),
):
    """B10/C103-5 平台采集：pages 列表（绝对 URL 或站点相对路径）→ 后台只读采集 → 样本 JSON。"""
    from app.services.xhr_capture_service import CaptureCapacityUnavailable, create_capture_task
    pages = [str(x) for x in (body.get("pages") or []) if str(x).strip()]
    if not pages:
        raise HTTPException(422, "pages 不能为空")
    try:
        task = create_capture_task(pages=pages, project_id=current.project_id or 0)
    except CaptureCapacityUnavailable as exc:
        raise HTTPException(429, '执行器繁忙，请稍后重试', headers={'Retry-After': '5'}) from exc
    return R.ok(task)


@router.get("/capture/{task_id}", response_model=R[dict], summary="采集任务状态与结果")
def get_capture(
    task_id: str,
    current: CurrentUser = Depends(require_permission("uitest:detail")),
):
    from app.services.xhr_capture_service import get_task
    task = get_task(task_id)
    if not task:
        raise HTTPException(404, "采集任务不存在")
    return R.ok(task)


@router.get("/runner/health", response_model=R[dict], summary="Runner 健康检查")
def runner_health(
    current: CurrentUser = Depends(require_permission("uitest:list")),
):
    """检查 Playwright runner 状态：npx、Playwright 版本、浏览器安装、并发数。"""
    import shutil
    import subprocess

    from app.services.playwright_executor import _check_playwright_installed, MAX_CONCURRENT
    from app.services.ui_runner_queue import ensure_processor_running, running_count as q_running

    # Ensure the thread pool is ready (lazy init)
    ensure_processor_running()

    # Check npx
    npx_path = shutil.which("npx")
    npx_ok = npx_path is not None

    # Check playwright version
    pw_ok, pw_version = _check_playwright_installed()

    # Check browser binaries via playwright install --dry-run
    browsers_ok = False
    if npx_path:
        try:
            result = subprocess.run(
                [npx_path, "playwright", "install", "--dry-run"],
                capture_output=True, text=True, timeout=15,
            )
            browsers_ok = result.returncode == 0
        except Exception:
            logger.warning("Playwright 版本探测失败，假定浏览器可用")

    return R.ok({
        "npx": npx_ok,
        "playwright": pw_ok,
        "version": pw_version if pw_ok else "N/A",
        "browsers_installed": browsers_ok,
        "max_concurrent": MAX_CONCURRENT,
        "running": q_running(),
    })


# ═══════════════════════════════════════════════════════
# 动态 {job_id} 路由（必须在静态路径之后注册）
# ═══════════════════════════════════════════════════════

@router.get("/{job_id}", response_model=R[UiTestJobDetailOut])
def get_job(
    job_id: int,
    current: CurrentUser = Depends(require_permission("uitest:detail")),
    db: Session = Depends(get_db),
):
    r = ui_test_service.get_job(db, job_id, current.project_id or 0)
    if not r:
        from app.core.exceptions import not_found
        raise not_found("UI测试任务")
    return R.ok(UiTestJobDetailOut(**r))


@router.put("/{job_id}", response_model=R[UiTestJobOut])
def update_job(
    req: Request, job_id: int, body: UiTestJobUpdate,
    current: CurrentUser = Depends(require_permission("uitest:code_execute")),
    db: Session = Depends(get_db),
):
    r = ui_test_service.update_job(db, job_id, body, current.project_id or 0)
    if not r:
        from app.core.exceptions import not_found
        raise not_found("UI测试任务")
    db.commit()
    _audit(req, current, db, "uitest:update", f"#{job_id}")
    return R.ok(UiTestJobOut(**r))


@router.delete("/{job_id}", response_model=R[dict])
def delete_job(
    req: Request, job_id: int,
    current: CurrentUser = Depends(require_permission("uitest:delete")),
    db: Session = Depends(get_db),
):
    ok = ui_test_service.delete_job(db, job_id, current.project_id or 0)
    if not ok:
        from app.core.exceptions import not_found
        raise not_found("UI测试任务")
    db.commit()
    _audit(req, current, db, "uitest:delete", f"job #{job_id}")
    return R.ok({"deleted": True})


@router.post("/{job_id}/trigger", response_model=R[UiTestRunOut])
def trigger_job(
    req: Request, job_id: int,
    body: UiTestTriggerRequest | None = None,
    current: CurrentUser = Depends(require_permission("uitest:code_execute")),
    db: Session = Depends(get_db),
):
    """触发 UI 测试 — 立即创建 run 并入队，由队列 worker 异步执行 Playwright。"""
    try:
        run_dict = ui_test_service.trigger_job(
            db,
            job_id,
            current.project_id or 0,
            confirm_prod=body.confirm_prod if body else False,
            has_trigger_prod=(
                current.is_super
                or "*" in current.permissions
                or "uitest:trigger_prod" in current.permissions
            ),
        )
        db.commit()
        _audit(req, current, db, "uitest:trigger", f"#{job_id} run=#{run_dict['id']}")
        return R.ok(UiTestRunOut(**run_dict))
    except PermissionError as e:
        raise HTTPException(403, str(e))
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.get("/{job_id}/runs", response_model=R[dict])
def get_runs(
    job_id: int,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    current: CurrentUser = Depends(require_permission("uitest:detail")),
    db: Session = Depends(get_db),
):
    items, total = ui_test_service.list_runs(
        db, job_id, current.project_id or 0, page=page, page_size=page_size,
    )
    return R.ok({"total": total, "page": page, "page_size": page_size, "items": items})
