"""APScheduler integration for cron-based test schedule execution."""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from app.core.config import settings

logger = logging.getLogger(__name__)

scheduler = BackgroundScheduler(timezone="Asia/Shanghai")


def _execute_schedule(schedule_id: int, run_id: int | None = None):
    """Callback fired by APScheduler when a cron trigger expires.

    Batch 163 / C162-1：支持由「手动触发」预创建 run 后传入 run_id 后台执行；
    未传 run_id 时保持原逻辑（自建 running run）。无论哪种路径都打开独立 DB session。
    """
    from app.core.db import SessionLocal
    from app.models.test_schedule import TestSchedule, TestScheduleRun
    from app.services.test_plan_service import execute_all_cases
    from sqlalchemy import select

    db = SessionLocal()
    try:
        # Serialize the claim in PostgreSQL. SQLite also serializes the
        # following write transaction, which keeps the local profile honest.
        sched = db.scalar(
            select(TestSchedule)
            .where(TestSchedule.id == schedule_id)
            .with_for_update()
        )
        if not sched or (run_id is None and not sched.enabled):
            logger.warning(f"[scheduler] Schedule #{schedule_id} not found, skipping")
            return {"triggered": False, "reason": "not_found"}

        if run_id is None:
            active_run = db.scalar(
                select(TestScheduleRun)
                .where(
                    TestScheduleRun.schedule_id == schedule_id,
                    TestScheduleRun.status == "running",
                )
                .order_by(TestScheduleRun.id.desc())
            )
            if active_run:
                db.rollback()
                logger.info(
                    "[scheduler] Schedule #%s already running as run #%s; duplicate trigger ignored",
                    schedule_id,
                    active_run.id,
                )
                return {
                    "triggered": False,
                    "reason": "already_running",
                    "run_id": active_run.id,
                }

            run = TestScheduleRun(
                schedule_id=schedule_id,
                status="running",
                started_at=datetime.now(timezone.utc),
            )
            db.add(run)
            db.flush()
            run_id = run.id
            db.commit()
        else:
            # Batch 163 / C162-1：手动触发已预建 run，这里校验并复用
            run = db.get(TestScheduleRun, run_id)
            if run is None or run.schedule_id != schedule_id:
                db.rollback()
                return {"triggered": False, "reason": "run_not_found", "run_id": run_id}
            from sqlalchemy import update

            claimed = db.execute(
                update(TestScheduleRun)
                .where(TestScheduleRun.id == run_id,
                       TestScheduleRun.status == 'running',
                       TestScheduleRun.heartbeat_at.is_(None))
                .values(heartbeat_at=datetime.now(timezone.utc))
            )
            if claimed.rowcount != 1:
                db.rollback()
                return {"triggered": False, "reason": "already_claimed", "run_id": run_id}

        # Batch 164 / C163-1：运行开始写入心跳，供 stale 回收判定
        run.heartbeat_at = datetime.now(timezone.utc)
        db.commit()

        if sched.job_type == "ui":
            # B112-3：UI job 定时 —— 触发 UI job（Playwright 异步执行，schedule run 记录 ui_run_id）
            from app.services.ui_test_service import trigger_job as trigger_ui_job

            ui_run = trigger_ui_job(
                db,
                sched.job_id,
                sched.project_id,
                confirm_prod=True,
                has_trigger_prod=True,
            )
            result = {
                "ui_run_id": ui_run.get("id"),
                "status": ui_run.get("status"),
                "total": 1,
                "pass_": 0,
                "fail": 0,
                "skip": 0,
                "block": 0,
                "pending": 1,
            }
        elif sched.job_type == "report":
            # 平台简化批次：报告中心已删除，job_type=report 的存量定时任务直接失败提示
            raise ValueError("报告中心已下线，请删除或改用计划执行类型的定时任务")
        else:
            execution_result = execute_all_cases(
                db,
                sched.plan_id,
                executor_id=0,
                environment_id=getattr(sched, "environment_id", None),
                project_id=sched.project_id,
            )
            result = {
                "total": execution_result["total"],
                "pass_": execution_result["passed"],
                "fail": execution_result["failed"],
                "skip": execution_result["skipped"],
                "block": 0,
                "pending": 0,
            }
        run = db.get(TestScheduleRun, run_id)
        sched = db.get(TestSchedule, schedule_id)
        if run is None or sched is None:
            raise RuntimeError("调度运行记录在执行期间被删除")
        # B2：运行状态按实际执行结果回填（不得硬编码 passed）
        fail_count = int(result.get("fail", 0) or 0)
        result_status = str(result.get("status", "") or "")
        if fail_count > 0:
            run.status = "failed"
        elif result_status in ("failed", "fail"):
            run.status = "failed"
        elif result_status in ("running", "pending", "started"):
            run.status = "running"
        else:
            run.status = "passed"
        run.result = json.dumps(result, ensure_ascii=False)
        run.heartbeat_at = datetime.now(timezone.utc)
        run.finished_at = datetime.now(timezone.utc)
        sched.last_run = datetime.now(timezone.utc)
        db.commit()
        logger.info(
            "[scheduler] Schedule #%s '%s' completed: %s",
            schedule_id,
            sched.name,
            result,
        )
        # 平台简化批次：通知体系已删除，任务完成不再推送

        return {"triggered": True, "run_id": run_id, "result": result}

    except Exception as e:
        logger.exception(f"[scheduler] Schedule #{schedule_id} failed: {e}")
        db.rollback()
        try:
            if "run_id" in locals():
                failed_run = db.get(TestScheduleRun, run_id)
                if failed_run is None:
                    raise RuntimeError("调度失败后无法找到运行记录")
                failed_run.status = "failed"
                failed_run.error_message = str(e)[:500]
                failed_run.heartbeat_at = datetime.now(timezone.utc)
                failed_run.finished_at = datetime.now(timezone.utc)
                db.commit()
        except Exception:
            logger.exception(
                "[scheduler] Failed to persist failure for schedule #%s",
                schedule_id,
            )

        # 平台简化批次：通知体系已删除
        return {
            "triggered": False,
            "reason": "execution_failed",
            "error": str(e)[:200],
        }
    finally:
        db.close()


def add_schedule_job(schedule_id: int, cron_expression: str):
    """Register a cron job for a schedule (idempotent)."""
    if not settings.worker_execution_enabled:
        return
    try:
        scheduler.add_job(
            func=_execute_schedule,
            trigger=CronTrigger.from_crontab(cron_expression),
            args=[schedule_id],
            id=f"schedule_{schedule_id}",
            replace_existing=True,
            max_instances=1,
            coalesce=True,
        )
        logger.info(f"[scheduler] Job added: schedule_{schedule_id} ({cron_expression})")
    except (ValueError, TypeError) as e:
        logger.error(f"[scheduler] Failed to add job schedule_{schedule_id}: {e}")


def remove_schedule_job(schedule_id: int):
    """Remove a cron job."""
    if not settings.worker_execution_enabled:
        return
    try:
        scheduler.remove_job(f"schedule_{schedule_id}")
        logger.info(f"[scheduler] Job removed: schedule_{schedule_id}")
    except Exception:
        pass  # job doesn't exist


def toggle_schedule_job(schedule_id: int, enabled: bool, cron_expression: str):
    """Enable or disable a schedule job."""
    if enabled:
        add_schedule_job(schedule_id, cron_expression)
    else:
        remove_schedule_job(schedule_id)


def refresh_schedule_jobs() -> None:
    """Reconcile schedules committed by a separate API process."""
    from app.core.db import SessionLocal
    from app.models.test_schedule import TestSchedule
    from sqlalchemy import select

    with SessionLocal() as db:
        desired = dict(db.execute(
            select(TestSchedule.id, TestSchedule.cron_expression).where(TestSchedule.enabled)
        ).all())
    for job in scheduler.get_jobs():
        suffix = job.id.removeprefix('schedule_')
        if job.id.startswith('schedule_') and suffix.isdigit() and int(suffix) not in desired:
            scheduler.remove_job(job.id)
    for schedule_id, expression in desired.items():
        current = scheduler.get_job(f'schedule_{schedule_id}')
        trigger = CronTrigger.from_crontab(expression)
        if current is None or str(current.trigger) != str(trigger):
            add_schedule_job(schedule_id, expression)


def poll_pending_schedule_runs() -> None:
    """Consume durable manual triggers without an API-owned execution thread."""
    from app.core.db import SessionLocal
    from app.models.test_schedule import TestScheduleRun
    from sqlalchemy import select

    with SessionLocal() as db:
        pending = db.execute(
            select(TestScheduleRun.id, TestScheduleRun.schedule_id)
            .where(TestScheduleRun.status == 'running', TestScheduleRun.heartbeat_at.is_(None))
            .order_by(TestScheduleRun.id).limit(1)
        ).first()
    if pending is not None:
        _execute_schedule(pending.schedule_id, pending.id)


# 平台简化批次：集成配置/同步引擎已删除，refresh_integration_jobs 一并移除


def _naive_utc(dt):
    if dt is None:
        return None
    if getattr(dt, "tzinfo", None) is not None:
        return dt.astimezone(timezone.utc).replace(tzinfo=None)
    return dt


def reap_stale_schedule_runs(db=None) -> int:
    """Batch 164 / C163-1：回收失联的调度运行记录（heartbeat 超时）。

    周期任务（默认每 5 分钟）+ 启动时执行一次。heartbeat_at 为 NULL 的旧数据按
    started_at 兜底；回收后将 run 置 failed，解除 already_running 对新触发的阻塞。
    db 为空时使用独立 SessionLocal（生产）；测试可注入会话。
    """
    from datetime import timedelta

    from app.core.config import settings
    from app.core.db import SessionLocal
    from app.models.test_schedule import TestScheduleRun
    from sqlalchemy import select

    own_session = db is None
    if own_session:
        db = SessionLocal()
    assert db is not None
    try:
        stale_after = timedelta(seconds=max(int(getattr(settings, "schedule_stale_seconds", 1200)), 60))
        now = datetime.utcnow()
        rows = db.scalars(
            select(TestScheduleRun).where(TestScheduleRun.status == "running")
        ).all()
        reaped = 0
        for r in rows:
            ref = _naive_utc(r.heartbeat_at or r.started_at)
            if ref is None:
                continue
            if now - ref > stale_after:
                r.status = "failed"
                r.error_message = (
                    f"stale: 执行失联超过 {int(stale_after.total_seconds())} 秒，已回收（Batch 164）"
                )
                r.heartbeat_at = datetime.now(timezone.utc)
                r.finished_at = r.heartbeat_at
                reaped += 1
        if reaped:
            db.commit()
            logger.warning("[scheduler] Reaped %s stale schedule run(s)", reaped)
        else:
            db.rollback()
        return reaped
    finally:
        if own_session:
            db.close()


def init_scheduler():
    """Called at app startup. Loads all enabled schedules from DB and registers jobs."""
    from app.core.db import SessionLocal
    from app.models.test_schedule import TestSchedule
    from sqlalchemy import select

    if not settings.worker_execution_enabled:
        return

    scheduler.start()
    logger.info("[scheduler] BackgroundScheduler started")

    db = SessionLocal()
    try:
        schedules = db.execute(
            select(TestSchedule).where(TestSchedule.enabled)
        ).scalars().all()

        for s in schedules:
            try:
                add_schedule_job(s.id, s.cron_expression)
            except Exception as e:
                logger.error(f"[scheduler] Failed to load schedule #{s.id}: {e}")

        logger.info(f"[scheduler] Loaded {len(schedules)} enabled schedules")
    finally:
        db.close()

    # ── 注册独立任务 Worker 轮询 ──
    from app.services.task_worker import poll_and_execute
    from apscheduler.triggers.interval import IntervalTrigger
    for job_id, callback, seconds in (
        ('schedule_registry_refresh', refresh_schedule_jobs, 5),
        ('manual_schedule_poll', poll_pending_schedule_runs, 2),
    ):
        scheduler.add_job(callback, trigger=IntervalTrigger(seconds=seconds),
                          id=job_id, replace_existing=True, max_instances=1, coalesce=True)
    try:
        scheduler.add_job(
            func=poll_and_execute,
            trigger=IntervalTrigger(seconds=5),
            id="task_worker_poll",
            replace_existing=True,
        )
        logger.info("[scheduler] Task worker poll registered (every 5s)")
    except Exception as e:
        logger.error(f"[scheduler] Failed to register task worker: {e}")

    # ── Batch 164 / C163-1：调度运行 stale 回收（每 5 分钟 + 启动即跑）──
    try:
        scheduler.add_job(
            func=reap_stale_schedule_runs,
            trigger=IntervalTrigger(seconds=300),
            id="schedule_stale_reap",
            replace_existing=True,
        )
        reap_stale_schedule_runs()
        logger.info("[scheduler] Schedule stale reaper registered (every 5min)")
    except Exception as e:
        logger.error(f"[scheduler] Failed to register stale reaper: {e}")

    # ── 知识保鲜退化 + 自动归档（每天凌晨 3:00）──
    try:
        from app.services.knowledge.source_service import decay_freshness_in_new_session
        scheduler.add_job(
            func=decay_freshness_in_new_session,
            trigger=CronTrigger(hour=3, minute=7),
            id="knowledge_freshness_decay",
            replace_existing=True,
        )
        logger.info("[scheduler] Knowledge freshness decay registered (daily 03:07)")
    except Exception as e:
        logger.error(f"[scheduler] Failed to register freshness decay: {e}")

    # ── 向量嵌入补跑（知识检索底座；每天凌晨 3:31）──
    if settings.knowledge_embedding_schedule_enabled:
        from app.services.knowledge.vectorize import embed_pending_projects_in_new_session

        scheduler.add_job(
            embed_pending_projects_in_new_session,
            trigger=CronTrigger(hour=3, minute=31, timezone=scheduler.timezone),
            id='knowledge_embedding_catchup', replace_existing=True, max_instances=1,
            coalesce=True,
        )

    # 平台简化批次：知识图谱自演化（entity_service/graph_builder）已随图谱模块删除

    # ── 存储保留期清理（每日定时 + 启动即跑；生产磁盘防护）──
    try:
        from app.services.storage_retention import cleanup_storage

        if settings.storage_retention_enabled:
            scheduler.add_job(
                func=cleanup_storage,
                trigger=CronTrigger(
                    hour=settings.storage_retention_hour,
                    minute=settings.storage_retention_minute,
                ),
                id="storage_retention_cleanup",
                replace_existing=True,
            )
            cleanup_storage()
            logger.info(
                "[scheduler] Storage retention cleanup registered (daily %02d:%02d)",
                settings.storage_retention_hour,
                settings.storage_retention_minute,
            )
        else:
            logger.info(
                "[scheduler] Storage retention cleanup disabled "
                "(STORAGE_RETENTION_ENABLED=false)"
            )
    except Exception as e:
        logger.error(f"[scheduler] Failed to register storage retention: {e}")


def shutdown_scheduler():
    """Called at app shutdown."""
    scheduler.shutdown(wait=False)
    logger.info("[scheduler] BackgroundScheduler shut down")
