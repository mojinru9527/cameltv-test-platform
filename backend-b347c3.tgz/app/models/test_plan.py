"""测试计划 + 计划用例关联 + 执行记录 模型。"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base


class TestPlan(Base):
    __tablename__ = "test_plan"

    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(default=0, index=True)
    plan_id: Mapped[str] = mapped_column(default="")
    name: Mapped[str] = mapped_column(default="")
    description: Mapped[str] = mapped_column(default="")
    status: Mapped[str] = mapped_column(default="draft")  # draft/active/completed/archived
    creator_id: Mapped[int] = mapped_column(default=0)
    assignee_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("sys_user.id"), default=None, index=True,
        comment="指派执行人",
    )
    start_date: Mapped[Optional[datetime]] = mapped_column(default=None)
    end_date: Mapped[Optional[datetime]] = mapped_column(default=None)
    due_date: Mapped[Optional[datetime]] = mapped_column(
        default=None, comment="截止日期",
    )
    created_at: Mapped[datetime] = mapped_column(default=datetime.now)
    updated_at: Mapped[datetime] = mapped_column(default=datetime.now, onupdate=datetime.now)

    # Batch 155 (C147-6): 失败自动转缺陷/报告/通知开关（列由迁移 20260811_batch151_auto_defect 创建）
    auto_defect_on_fail: Mapped[bool] = mapped_column(
        default=False, server_default="false",
        comment="失败自动转缺陷/报告/通知开关（默认关闭）",
    )

    # relations
    plan_cases: Mapped[list["TestPlanCase"]] = relationship(
        "TestPlanCase", back_populates="plan",
        cascade="all, delete-orphan", order_by="TestPlanCase.sort_order",
    )


class TestPlanCase(Base):
    __tablename__ = "test_plan_case"

    id: Mapped[int] = mapped_column(primary_key=True)
    plan_id: Mapped[int] = mapped_column(ForeignKey("test_plan.id"), index=True)
    case_id: Mapped[int] = mapped_column(default=0, index=True)
    sort_order: Mapped[int] = mapped_column(default=0)
    last_status: Mapped[str] = mapped_column(default="pending")  # pending/pass/fail/skip/block
    last_executed_at: Mapped[Optional[datetime]] = mapped_column(default=None)
    executor_id: Mapped[int] = mapped_column(default=0)
    created_at: Mapped[datetime] = mapped_column(default=datetime.now)

    # relations
    plan: Mapped["TestPlan"] = relationship("TestPlan", back_populates="plan_cases")
    executions: Mapped[list["TestExecution"]] = relationship(
        "TestExecution", back_populates="plan_case",
        cascade="all, delete-orphan", order_by="TestExecution.executed_at.desc()",
    )


class TestExecution(Base):
    __tablename__ = "test_execution"

    id: Mapped[int] = mapped_column(primary_key=True)
    plan_case_id: Mapped[int] = mapped_column(ForeignKey("test_plan_case.id"), index=True)
    executor_id: Mapped[int] = mapped_column(default=0)
    status: Mapped[str] = mapped_column(default="pending")  # Batch 182（P1-06）：pending/running/passed/failed/skipped/cancelled/blocked
    actual_result: Mapped[str] = mapped_column(default="")
    notes: Mapped[str] = mapped_column(default="")
    trace_id: Mapped[str] = mapped_column(default="")       # ELK traceId
    # Batch 148 (C147-2): 失败根因独立字段，UI 直接展示；历史行由 actual_result JSON 回填解析
    status_code: Mapped[int] = mapped_column(default=0, comment="最近一次执行的 HTTP 状态码，0=未发出请求")
    error_type: Mapped[str] = mapped_column(
        String(50), default="", comment="失败阶段/错误类型: TARGET_POLICY/TIMEOUT/NETWORK_ERROR/ASSERTION_FAILED/EXECUTION_ERROR"
    )
    error_message: Mapped[str] = mapped_column(Text, default="", comment="失败原因摘要")
    # Batch 157：关联接口执行任务（trigger_type=plan 时由计划 API 执行登记）
    api_task_id: Mapped[Optional[int]] = mapped_column(default=None, index=True)
    executed_at: Mapped[datetime] = mapped_column(default=datetime.now)
    created_at: Mapped[datetime] = mapped_column(default=datetime.now)

    # relations
    plan_case: Mapped["TestPlanCase"] = relationship("TestPlanCase", back_populates="executions")

