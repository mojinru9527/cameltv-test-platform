"""Canonical Campaign orchestration domain."""
