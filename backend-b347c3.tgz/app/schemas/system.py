"""系统管理 Pydantic 模型 —— 用户 / 角色 / 权限 / 审计 + 菜单。

MenuOut.sort uses field_validator(mode='before') to coerce float->int (fix 2026-07-20).
"""
from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


# ── 菜单 ──

from typing import Any

from pydantic import field_validator


class MenuOut(BaseModel):
    code: str
    name: str
    path: str = ""
    icon: str = ""
    sort: int = 0
    children: list["MenuOut"] = []

    @field_validator("sort", mode="before")
    @classmethod
    def coerce_sort(cls, v: Any) -> int:
        """数据库 sort 字段历史数据可能存为 REAL（如 10.5），统一转 int。"""
        return int(v)


MenuOut.model_rebuild()


# ── 用户 ──

class UserBrief(BaseModel):
    """兼容 auth schema 的同名模型；system 侧有更完整版。"""
    model_config = ConfigDict(from_attributes=True)
    id: int
    username: str
    nickname: str
    email: str
    status: int = 1


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    username: str
    nickname: str = ""
    email: str = ""
    status: int = 1
    # 关联的角色 code 列表（填入 UserRole 中 global + 该 project 的角色）
    role_codes: list[str] = Field(default_factory=list)
    created_at: datetime | None = None
    last_login_at: datetime | None = None


class UserCreate(BaseModel):
    username: str
    password: str = Field(..., min_length=6, description="密码，最少 6 位，无默认值")
    nickname: str = ""
    email: str = ""
    status: int = 1
    role_codes: list[str] = Field(default_factory=list)


class UserUpdate(BaseModel):
    username: str | None = None
    nickname: str | None = None
    email: str | None = None
    status: int | None = None
    password: str | None = None      # 不填则不修改密码
    role_codes: list[str] | None = None


# ── 角色 ──

class RoleBrief(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    code: str
    name: str


class RoleOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    code: str
    name: str
    data_scope: str = "project"
    remark: str = ""
    permission_codes: list[str] = Field(default_factory=list)
    created_at: datetime | None = None


class RoleCreate(BaseModel):
    code: str
    name: str
    data_scope: str = "project"
    remark: str = ""
    permission_codes: list[str] = Field(default_factory=list)


class RoleUpdate(BaseModel):
    name: str | None = None
    data_scope: str | None = None
    remark: str | None = None
    permission_codes: list[str] | None = None


# ── 权限 ──

class PermissionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    code: str
    name: str
    type: str = "menu"
    parent_id: int = 0
    path: str = ""
    icon: str = ""
    sort: int = 0


class PermissionGroup(BaseModel):
    """按分组整理的权限列表，前端 Checkbox 用。"""
    group: str = ""
    items: list["PermissionOut"] = Field(default_factory=list)


# ── 审计 ──

class AuditLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    user_id: int = 0
    username: str = ""
    project_id: int = 0
    action: str = ""
    target: str = ""
    detail: str = ""
    ip: str = ""
    created_at: datetime | None = None


# ── 注册邀请码（Batch 104 外放轻量模式）──

class InviteCodeIn(BaseModel):
    usage_limit: int = Field(1, ge=1, le=1000, description="可注册次数上限")
    expires_at: datetime | None = Field(None, description="过期时间（UTC ISO）；空=永不过期")


class InviteCodeOut(BaseModel):
    id: int
    code: str
    created_by: int = 0
    created_by_name: str = ""
    usage_limit: int = 1
    used_count: int = 0
    expires_at: datetime | None = None
    status: int = 1
    created_at: datetime | None = None
