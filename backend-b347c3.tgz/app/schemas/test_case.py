"""测试用例 Schema — 请求/响应模型。"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


# ── 响应 ──────────────────────────────────────────────

class TestCaseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    project_id: int = 0
    case_id: str = ""
    title: str = ""
    domain: str = ""
    module: str = ""
    case_type: str = "manual"
    surface: str = "其他"
    taxonomy_domain: str = "未分类"
    taxonomy_module: str = ""
    terminal_scopes: list[str] = Field(default_factory=list)
    priority: str = "P2"
    status: str = "active"
    tags: str = "[]"
    case_design_method: str = ""
    positive_negative: str = ""
    test_data_note: str = ""
    preconditions: str = ""
    steps: str = "[]"
    expected_result: str = ""
    api_method: str = ""
    api_endpoint: str = ""
    api_spec_ref: str = ""
    api_headers: str = "{}"
    api_body: str = ""
    api_assertions: str = "[]"
    depends_on_ids: str = "[]"
    last_response_json: str = ""
    last_run_status: str = ""
    source: str = "migration"
    source_req_id: str = ""
    source_doc_id: Optional[int] = None
    dataset_id: Optional[int] = None
    old_id: Optional[int] = None
    review_status: str = "draft"
    review_comment: str = ""
    reviewer_id: int = 0
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class TestCaseBrief(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    case_id: str = ""
    title: str = ""
    domain: str = ""
    module: str = ""
    case_type: str = "manual"
    priority: str = "P2"


# ── 请求 ──────────────────────────────────────────────

class TestCaseCreate(BaseModel):
    project_id: int = 0
    case_id: str = ""
    title: str
    domain: str = ""
    module: str = ""
    case_type: str = "manual"
    priority: str = "P2"
    status: str = "active"
    tags: str = "[]"
    case_design_method: str = ""
    positive_negative: str = ""
    test_data_note: str = ""
    preconditions: str = ""
    steps: str = "[]"
    expected_result: str = ""
    api_method: str = ""
    api_endpoint: str = ""
    api_spec_ref: str = ""
    api_headers: str = "{}"
    api_body: str = ""
    api_assertions: str = "[]"
    depends_on_ids: str = "[]"
    last_response_json: str = ""
    last_run_status: str = ""
    source: str = "manual"
    source_req_id: str = ""
    dataset_id: Optional[int] = None


class TestCaseUpdate(BaseModel):
    case_id: Optional[str] = None
    title: Optional[str] = None
    domain: Optional[str] = None
    module: Optional[str] = None
    case_type: Optional[str] = None
    priority: Optional[str] = None
    status: Optional[str] = None
    tags: Optional[str] = None
    case_design_method: Optional[str] = None
    positive_negative: Optional[str] = None
    test_data_note: Optional[str] = None
    preconditions: Optional[str] = None
    steps: Optional[str] = None
    expected_result: Optional[str] = None
    api_method: Optional[str] = None
    api_endpoint: Optional[str] = None
    api_spec_ref: Optional[str] = None
    api_headers: Optional[str] = None
    api_body: Optional[str] = None
    api_assertions: Optional[str] = None
    depends_on_ids: Optional[str] = None
    last_response_json: Optional[str] = None
    last_run_status: Optional[str] = None
    source_req_id: Optional[str] = None
    source_doc_id: Optional[int] = None
    dataset_id: Optional[int] = None


# ── 查询参数 ──────────────────────────────────────────

class TestCaseFilter(BaseModel):
    case_id: str = ""
    domain: str = ""
    module: str = ""
    surface: str = ""
    taxonomy_domain: str = ""
    taxonomy_module: str = ""
    case_type: str = ""           # 空=全部
    positive_negative: str = ""
    priority: str = ""
    status: str = ""
    keyword: str = ""
    page: int = 1
    page_size: int = 20


# ── 域树 ──────────────────────────────────────────────

class ModuleNode(BaseModel):
    id: Optional[int] = None
    module: str
    count: int = 0


class DomainNode(BaseModel):
    id: Optional[int] = None
    domain: str
    count: int = 0
    modules: list[ModuleNode] = []


class TaxonomyModuleNode(BaseModel):
    name: str
    path: str
    count: int = 0
    children: list["TaxonomyModuleNode"] = Field(default_factory=list)


class TaxonomyDomainNode(BaseModel):
    domain: str
    count: int = 0
    modules: list[TaxonomyModuleNode] = Field(default_factory=list)


class TaxonomySurfaceNode(BaseModel):
    surface: str
    count: int = 0
    domains: list[TaxonomyDomainNode] = Field(default_factory=list)


TaxonomyModuleNode.model_rebuild()


# ── 域/模块分类请求 ───────────────────────────────────

class DomainCreate(BaseModel):
    name: str


class ModuleCreate(BaseModel):
    name: str
