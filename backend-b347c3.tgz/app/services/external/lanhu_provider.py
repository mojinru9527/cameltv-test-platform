"""蓝湖(Lanhu) MCP Provider —— 统一的原型/需求提取来源。

从 ai_service.py 抽离（保持提取行为完全一致），供需求生成、知识中心 Raw Source、
Wiki 编译流水线统一复用。ai_service 通过 `from ... import _extract_lanhu_content` 委托调用。

- `_extract_lanhu_content(url, auto_login)`：原始提取，返回
  {content, page_filtered, folder_name, changelog, client_scope}，异常语义与原实现一致。
- `extract(url, auto_login)`：标准化入口，返回 LanhuExtractResult（永不抛异常，以状态表达失败）。
"""
from __future__ import annotations

import asyncio
import html
import hashlib
import inspect
import logging

logger = logging.getLogger(__name__)
import re
import sys
from pathlib import Path
from types import SimpleNamespace

import httpx

from app.core.config import settings


_LANHU_DOWNLOAD_MAX_RESOURCES = 1000
_LANHU_DOWNLOAD_MAX_TOTAL_BYTES = 300 * 1024 * 1024
_LANHU_DOWNLOAD_TIMEOUT_SECONDS = 300
# Batch 159：证据提取整体超时（旧版 lanhu-mcp 无整体超时，单请求仅 30s）
_LANHU_EVIDENCE_TIMEOUT_SECONDS = 600


class LanhuManualActionRequired(ValueError):
    """Resource download was incomplete and must not be treated as usable evidence."""


def _resolve_workspace_root() -> Path:
    """Resolve workspace root from config or auto-detect from this file's location.

    external/lanhu_provider.py 比原 services/ai_service.py 深一层，故多回退一级。
    """
    if settings.workspace_root:
        return Path(settings.workspace_root)
    return Path(__file__).resolve().parent.parent.parent.parent.parent.parent

def _lanhu_mcp_dir() -> Path:
    """Return the lanhu-mcp module directory."""
    if settings.lanhu_mcp_dir:
        return Path(settings.lanhu_mcp_dir)
    return _resolve_workspace_root() / "lanhu-mcp"


def _data_dir() -> Path:
    """Return the extracted data cache directory."""
    if settings.data_dir:
        return Path(settings.data_dir)
    return _resolve_workspace_root() / "test-platform-v2" / "backend" / "data"


def _is_lanhu_session_expired(exc: BaseException) -> bool:
    """将蓝湖 401/403/418 视为会话失效（Cookie 过期/被拒/反爬），触发重登或明确报错。"""
    import httpx

    seen: BaseException | None = exc
    while seen is not None:
        if (
            isinstance(seen, httpx.HTTPStatusError)
            and seen.response is not None
            and seen.response.status_code in (401, 403, 418)
        ):
            return True
        seen = seen.__cause__
    return False


_LANHU_COOKIE_FILE = "lanhu_cookie.txt"


def set_lanhu_cookie(cookie: str) -> None:
    """保存用户更新后的蓝湖 Cookie（仅存 Cookie，不存密码）。"""
    from pathlib import Path

    value = (cookie or "").strip()
    if not value or value == "your_lanhu_cookie_here":
        raise ValueError("Cookie 不能为空，且不能使用默认占位值")
    path = Path(_data_dir()) / _LANHU_COOKIE_FILE
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value, encoding="utf-8")


def get_lanhu_cookie() -> str:
    """读取已保存的蓝湖 Cookie；无则返回空串（回退环境变量 LANHU_COOKIE）。"""
    from pathlib import Path

    path = Path(_data_dir()) / _LANHU_COOKIE_FILE
    if not path.exists():
        return ""
    try:
        return path.read_text(encoding="utf-8").strip()
    except Exception:  # noqa: BLE001
        return ""


async def _login_lanhu_with_retry(runtime, tries: int = 2, delay: float = 2.0) -> str:
    """Batch 161：蓝湖自动登录带重试，成功返回新 Cookie。

    未配置 LANHU_USERNAME/LANHU_PASSWORD 或多次失败时抛 ValueError，
    由调用方转换为可操作的 manual_action_required 提示。
    """
    import os

    if not os.environ.get("LANHU_USERNAME") or not os.environ.get("LANHU_PASSWORD"):
        raise ValueError("未配置 LANHU_USERNAME/LANHU_PASSWORD，无法自动登录")
    last_err: Exception | None = None
    for attempt in range(tries):
        try:
            cookie = await runtime.login()
            if cookie:
                return cookie
            last_err = ValueError(f"第 {attempt + 1} 次登录未返回 Cookie")
        except Exception as exc:  # noqa: BLE001 - 登录失败需重试/透出
            last_err = exc
        if attempt < tries - 1:
            await asyncio.sleep(delay)
    raise ValueError(f"蓝湖自动登录失败（{tries} 次尝试）：{str(last_err or '')[:200]}")


def _persist_lanhu_cookie(cookie: str, runtime) -> None:
    """Batch 161：登录成功后同时持久化到平台数据目录与 lanhu-mcp 运行态。"""
    set_lanhu_cookie(cookie)
    if runtime is not None and runtime.save_cookie is not None:
        runtime.save_cookie(cookie)


def clear_lanhu_cookie() -> None:
    """清除已保存的蓝湖 Cookie（会话失效且用户选择退出时）。"""
    from pathlib import Path

    path = Path(_data_dir()) / _LANHU_COOKIE_FILE
    if path.exists():
        path.unlink()


def _load_lanhu_runtime() -> SimpleNamespace:
    """Load the pinned lanhu-mcp API while tolerating optional login helpers."""
    import lanhu_mcp_server as module  # type: ignore

    auth_error = getattr(module, "LanhuAuthError", None)
    auth_error_types = (
        (auth_error,)
        if isinstance(auth_error, type) and issubclass(auth_error, BaseException)
        else ()
    )
    return SimpleNamespace(
        LanhuExtractor=module.LanhuExtractor,
        fix_html_files=module.fix_html_files,
        auth_error_types=auth_error_types,
        login=getattr(module, "lanhu_login", None),
        save_cookie=getattr(module, "_save_cached_cookie", None),
        module=module,
    )


def _create_lanhu_extractor(runtime: SimpleNamespace, cookie_override: str = ""):
    """Instantiate pinned or newer extractors without assuming cookie support.

    lanhu-mcp 的 LanhuExtractor 从模块级 COOKIE（env LANHU_COOKIE）读取 Cookie，而
    不是 __init__ 参数；因此传入已保存/新登录的 Cookie 时必须先注入模块全局再实例化，
    否则保存的 Cookie 永远不生效，采集任务持续报"蓝湖会话已失效"（Batch 136）。
    """
    if cookie_override:
        module = getattr(runtime, "module", None)
        if module is not None:
            module.COOKIE = cookie_override
            module.DDS_COOKIE = cookie_override
    parameters = inspect.signature(runtime.LanhuExtractor).parameters
    if "cookie" in parameters:
        return runtime.LanhuExtractor(cookie=cookie_override)
    return runtime.LanhuExtractor()


async def _download_lanhu_resources(
    extractor,
    url: str,
    output_dir: str,
    target_version_id: str,
    target_page_id: str = "",
) -> dict:
    """Call old or bounded lanhu-mcp downloads with only supported arguments."""
    parameters = inspect.signature(extractor.download_resources).parameters
    optional_arguments = {
        "target_page_id": target_page_id or None,
        "target_version_id": target_version_id or None,
        "max_resources": _LANHU_DOWNLOAD_MAX_RESOURCES,
        "max_total_bytes": _LANHU_DOWNLOAD_MAX_TOTAL_BYTES,
        "overall_timeout": _LANHU_DOWNLOAD_TIMEOUT_SECONDS,
    }
    supported_arguments = {
        name: value
        for name, value in optional_arguments.items()
        if name in parameters
    }
    return await extractor.download_resources(
        url,
        output_dir,
        **supported_arguments,
    )


async def _download_lanhu_resources_scoped(
    extractor,
    url: str,
    output_dir: str,
    params: dict,
    pages_info: dict,
    *,
    cdn_url: str,
    target_page_id: str,
    capture_all_pages: bool,
) -> dict | None:
    """Batch 159：按页/按文件夹有界下载，避免整版全量下载导致超时。

    仅当 capture_all_pages=False 且目标 pageId 存在于最新版 sitemap 时启用；
    文件名无法匹配或一页都没下到则返回 None（调用方回退全量下载，保留真实错误路径）。
    """
    if capture_all_pages or not target_page_id or not cdn_url:
        return None
    pages = pages_info.get("pages", []) or []
    target = next((pg for pg in pages if str(pg.get("id")) == str(target_page_id)), None)
    if target is None:
        return None
    folder = str(target.get("folder") or "")
    needed = [pg for pg in pages if (str(pg.get("folder") or "") == folder)] if folder else [target]
    needed_names = {str(pg.get("filename") or "") for pg in needed}
    needed_names.discard("")
    if not needed_names:
        return None

    doc_info = await extractor.get_document_info(
        str(params.get("project_id") or ""),
        str(params.get("doc_id") or ""),
        team_id=params.get("team_id") or None,
        page_id=target_page_id,
    )
    versions = doc_info.get("versions", []) or []
    if not versions:
        return None
    version_info = versions[0]
    version_id = str(version_info.get("id") or "")
    json_url = version_info.get("json_url")
    if not json_url:
        return None
    resp = await extractor.client.get(json_url)
    resp.raise_for_status()
    project_mapping = resp.json()
    pages_map = project_mapping.get("pages", {}) or {}
    if not isinstance(pages_map, dict) or not needed_names.issubset(set(pages_map.keys())):
        return None

    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    downloaded: list[str] = []
    for index, name in enumerate(sorted(needed_names)):
        entry = pages_map.get(name) or {}
        html_md5 = (entry.get("html") or {}).get("sign_md5", "")
        if html_md5:
            html_url = html_md5 if html_md5.startswith("http") else f"{cdn_url}/{html_md5}"
            try:
                html_resp = await extractor.client.get(html_url)
                html_resp.raise_for_status()
                (output_path / name).write_text(html_resp.text, encoding="utf-8")
                downloaded.append(name)
            except Exception:
                continue
        mapping_md5 = entry.get("mapping_md5", "")
        if mapping_md5:
            mapping_url = mapping_md5 if mapping_md5.startswith("http") else f"{cdn_url}/{mapping_md5}"
            try:
                map_resp = await extractor.client.get(mapping_url)
                map_resp.raise_for_status()
                page_mapping = map_resp.json()
                await extractor._download_page_resources(page_mapping, output_path, skip_document_js=(index > 0))
            except Exception:
                # 资源URL/下载失败仅降级为「未下载该页资源」，不影响主下载流程。
                pass
    if not downloaded:
        return None
    try:
        extractor._save_cache_meta(output_path, {
            "version_id": version_id,
            "document_id": str(params.get("doc_id") or ""),
            "document_name": doc_info.get("name", "Unknown"),
            "download_time": asyncio.get_running_loop().time(),
            "pages": sorted(needed_names),
            "total_files": len(downloaded),
            "scoped": True,
        })
    except Exception:
        # 缓存元数据写入失败不影响下载结果，留待下次再写。
        pass
    return {
        "status": "downloaded",
        "version_id": version_id,
        "reason": "scoped_pages",
        "output_dir": output_dir,
    }


def _ensure_download_is_usable(download_result: dict) -> None:
    """Reject bounded/partial downloads before they can become formal evidence."""
    status = str(download_result.get("status") or "")
    if status in {"downloaded", "updated", "cached"}:
        return
    if status in {"limited", "downloaded_with_errors"} or download_result.get(
        "manual_action_required"
    ):
        manual_message = str(download_result.get("manual_action_message") or "").strip()
        if manual_message:
            raise LanhuManualActionRequired(manual_message[:300])
        reason = str(
            download_result.get("limit_reason")
            or download_result.get("reason")
            or status
            or "resource_failure"
        )
        raise LanhuManualActionRequired(
            f"蓝湖资源下载未完整完成（{reason}），请人工处理"
        )
    raise ValueError(f"蓝湖资源下载失败（{status or 'unknown'}），请稍后重试")


# ── Changelog & Client Detection ──────────────────────────────

# Page name patterns that identify changelog / version history pages.
# These are now PRIORITIZED for extraction (not skipped).
_CHANGELOG_PAGE_PATTERNS = [
    "更新日志", "版本记录", "版本历史", "更新记录", "修订记录",
    "changelog", "version history", "revision history", "change log",
    "修订历史", "修改记录", "历史版本",
]

# Client platform detection patterns for folder/page names
_CLIENT_PATTERNS: dict[str, list[str]] = {
    "app": ["app端", "app", "移动端", "手机端", "android", "ios", "安卓", "苹果"],
    "pc": ["pc端", "pc", "桌面端", "电脑端", "windows", "mac", "客户端"],
    "web": ["web端", "web", "h5", "网页端", "浏览器", "h5端"],
}

# Cross-platform keywords
_CROSS_PLATFORM_KEYWORDS = ["三端", "全端", "通用", "多端", "所有端", "全平台"]


def _is_changelog_page(page_name: str) -> bool:
    """Return True if this page is a changelog / version history page.

    These pages are PRIORITIZED for extraction to identify versions.
    """
    name_lower = page_name.strip().lower()
    for pat in _CHANGELOG_PAGE_PATTERNS:
        if pat in name_lower:
            return True
    return False


def _detect_client_scope(name: str) -> list[str]:
    """Detect which client platforms a folder/page name suggests.

    Returns a list of client identifiers: ["app"], ["pc"], ["web"],
    or ["app", "pc", "web"] for cross-platform content.
    """
    name_lower = name.strip().lower()

    # Check cross-platform first
    for kw in _CROSS_PLATFORM_KEYWORDS:
        if kw in name_lower:
            return ["app", "pc", "web"]

    clients: list[str] = []
    for client_id, patterns in _CLIENT_PATTERNS.items():
        for pat in patterns:
            if pat in name_lower:
                if client_id not in clients:
                    clients.append(client_id)
                break

    return clients if clients else []


def _extract_changelog_text(changelog_pages: list[dict], resource_dir: str) -> str:
    """Extract text content from changelog pages.

    These pages are prioritized — they contain version information
    needed to guide the requirement extraction process.
    """
    parts: list[str] = []
    for p in changelog_pages:
        page_name = p.get("name", "")
        filename = p.get("filename", f'{page_name}.html')
        html_path = Path(resource_dir) / filename
        if html_path.exists():
            text = _extract_page_text(html_path)
            if text:
                parts.append(f"## {page_name}\n\n{text}")
    return "\n\n".join(parts)


def _analyze_version_structure_v2(all_pages: list[dict]) -> dict:
    """Analyze sitemap pages to identify version-folder structure with client detection.

    Enhanced version of _analyze_version_structure that additionally:
    - Detects client scope for each version group
    - Identifies changelog pages for prioritized extraction
    - Groups cross-platform pages separately

    Returns:
        {
            "has_version_structure": bool,
            "changelog_pages": [...],
            "version_groups": [{"name": str, "pages": [...], "client_scope": [...]}],
            "ungrouped_pages": [...],
            "cross_platform_pages": [...],
        }
    """
    changelog_pages: list[dict] = []
    version_groups_map: dict[str, list[dict]] = {}
    ungrouped_pages: list[dict] = []
    cross_platform_pages: list[dict] = []

    for p in all_pages:
        page_name = p.get("name", "")
        path: str = p.get("path", page_name)
        path_parts = [seg for seg in path.split("/") if seg]

        if len(path_parts) <= 1:
            if _is_changelog_page(page_name):
                changelog_pages.append(p)
            else:
                ungrouped_pages.append(p)
        else:
            top_folder = path_parts[0]
            # Check if this top folder is cross-platform
            folder_clients = _detect_client_scope(top_folder)
            if len(folder_clients) >= 3:
                cross_platform_pages.append(p)
            version_groups_map.setdefault(top_folder, []).append(p)

    version_groups = []
    for name, pages in version_groups_map.items():
        clients = _detect_client_scope(name)
        version_groups.append({
            "name": name,
            "pages": pages,
            "client_scope": clients,
        })

    has_version_structure = len(version_groups) >= 1

    return {
        "has_version_structure": has_version_structure,
        "changelog_pages": changelog_pages,
        "version_groups": version_groups,
        "ungrouped_pages": ungrouped_pages,
        "cross_platform_pages": cross_platform_pages,
    }


# ── Page Text Extraction ─────────────────────────────────────

# Max total chars for extracted page content (avoid overwhelming the AI).
_MAX_EXTRACTED_CHARS = 22000


def _extract_page_text(html_path: Path) -> str:
    """Extract clean visible text from a single Axure HTML page.

    Strips <script>, <style>, <noscript> and collapses whitespace.
    Returns the stripped text (may be empty for image-only pages).
    """
    from bs4 import BeautifulSoup as _BS

    html_content = html_path.read_text(encoding="utf-8", errors="replace")
    soup = _BS(html_content, "html.parser")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    text = soup.get_text(separator="\n", strip=True)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r"[ \t]{3,}", "  ", text)
    return text.strip()


# ── Lanhu Content Extraction ─────────────────────────────────

async def _extract_lanhu_content(url: str, auto_login: bool = True) -> dict:
    """Extract text content from a Lanhu Axure document URL.

    CHANGELOG-FIRST PIPELINE:
    1. Download Axure resources (cached by version)
    2. Get sitemap → identify changelog pages + version structure + client scope
    3. Extract changelog text FIRST to understand versions
    4. Extract requirement content from version-grouped folders
    5. Tag content with detected client_scope

    Returns a dict with:
      - content: structured text for AI consumption
      - page_filtered: bool
      - folder_name: str
      - changelog: dict | None (parsed version info)
      - client_scope: list[str] (detected platforms)
    """
    sys.path.insert(0, str(_lanhu_mcp_dir()))
    try:
        runtime = _load_lanhu_runtime()

        _page_id = ''
        if 'pageId=' in url:
            m = re.search(r'pageId=([^&]+)', url)
            if m:
                _page_id = m.group(1)

        async def _do_extract(cookie_override: str = "", page_id: str = "") -> dict:
            if not cookie_override:
                cookie_override = get_lanhu_cookie()
            extractor = _create_lanhu_extractor(runtime, cookie_override)

            params = extractor.parse_url(url)
            doc_id = params["doc_id"]
            url_version_id = params.get("version_id", "")
            effective_url = url

            # ── Handle project-level URLs (no docId) — 共享 helper（C87-1）──
            if not doc_id:
                try:
                    effective_url, doc_id = await _resolve_project_doc(url, extractor)
                    params = extractor.parse_url(effective_url)
                    url_version_id = params.get("version_id", "")
                except ValueError:
                    pass  # Fall through to the detailed error message below

                if not doc_id:
                    raise ValueError(
                        "蓝湖链接缺少文档 ID（docId 参数）。\n\n"
                        "您当前提交的是蓝湖「项目」链接，需要改为具体的「设计文档」链接。\n\n"
                        "获取正确链接的方法：\n"
                        "1. 在浏览器中打开蓝湖项目\n"
                        "2. 点击左侧菜单中的具体设计稿名称\n"
                        "3. 复制浏览器地址栏中的完整 URL\n"
                        "4. 该 URL 应包含 docId= 参数\n\n"
                        f"当前链接: {url[:120]}..."
                    )

            resource_dir = str(_data_dir() / f"axure_extract_{doc_id[:8]}")
            download_result = await _download_lanhu_resources(
                extractor,
                effective_url,
                resource_dir,
                url_version_id,
                page_id,
            )
            _ensure_download_is_usable(download_result)

            if download_result["status"] in ["downloaded", "updated"]:
                runtime.fix_html_files(resource_dir)

            pages_info = await extractor.get_pages_list(effective_url)
            all_pages = pages_info["pages"]
            doc_name = pages_info.get("document_name", "设计稿")

            page_filtered = False
            folder_name = ""
            full_page_count = len(all_pages)
            detected_clients: list[str] = []
            changelog_content = ""

            # ── Page-level filtering (when pageId is in URL) ──
            if page_id:
                target_page = None
                for p in all_pages:
                    if p.get('id') == page_id:
                        target_page = p
                        break

                if target_page is None:
                    logger.warning("[ai_service] WARNING: page_id='%s' not found in sitemap (%d pages), falling back to full extraction", page_id, full_page_count)
                else:
                    target_parent_id = target_page.get('parent_id', '')
                    target_own_id = target_page.get('id', '')
                    folder_name = target_page.get('folder', '')
                    detected_clients = _detect_client_scope(folder_name)

                    filtered_pages = []
                    for p in all_pages:
                        pid = p.get('parent_id', '')
                        if p.get('id') == page_id:
                            filtered_pages.append(p)
                        elif pid and pid == target_parent_id:
                            filtered_pages.append(p)
                        elif pid and pid == target_own_id:
                            filtered_pages.append(p)

                    if filtered_pages:
                        page_filtered = True
                        all_pages = filtered_pages
                        logger.info("[ai_service] Page-filtered extraction: %d/%d pages in folder '%s'", len(all_pages), full_page_count, folder_name)
                    else:
                        logger.warning("[ai_service] WARNING: page_id='%s' matched but no pages passed filter, falling back to full extraction", page_id)
            else:
                # ── Version-aware changelog-first extraction ──
                structure = _analyze_version_structure_v2(all_pages)

                # Step 1: Extract changelog FIRST
                changelog_text = _extract_changelog_text(
                    structure["changelog_pages"], resource_dir
                )
                if changelog_text:
                    changelog_content = changelog_text
                    logger.info("[ai_service] Changelog extracted: %d pages, %d chars", len(structure["changelog_pages"]), len(changelog_text))

                # Step 2: Collect all detected client scopes
                for vg in structure["version_groups"]:
                    for c in vg.get("client_scope", []):
                        if c not in detected_clients:
                            detected_clients.append(c)
                # Also check ungrouped pages
                for p in structure["ungrouped_pages"]:
                    for c in _detect_client_scope(p.get("name", "")):
                        if c not in detected_clients:
                            detected_clients.append(c)
                # And cross-platform pages
                for p in structure["cross_platform_pages"]:
                    for c in _detect_client_scope(p.get("name", "")):
                        if c not in detected_clients:
                            detected_clients.append(c)

                if structure["has_version_structure"]:
                    logger.info("[ai_service] Version-aware v2: %d version groups, changelog=%d pages, clients=%s in '%s' (%d pages)", len(structure["version_groups"]), len(structure["changelog_pages"]), detected_clients, doc_name, full_page_count)

                    overall_max = _MAX_EXTRACTED_CHARS * 3
                    per_version_budget = max(
                        _MAX_EXTRACTED_CHARS,
                        overall_max // max(len(structure["version_groups"]), 1),
                    )

                    version_sections: list[str] = []
                    total_extracted = 0
                    total_empty = 0
                    total_truncated = False
                    extracted_version_count = 0

                    for vg in structure["version_groups"]:
                        vg_name = vg["name"]
                        vg_pages = vg["pages"]
                        vg_clients = vg.get("client_scope", [])
                        vg_texts: list[str] = []
                        vg_chars = 0
                        vg_truncated = False

                        # Add client scope hint in version header
                        client_hint = f" [{'/'.join(vg_clients)}]" if vg_clients else ""

                        for p in vg_pages:
                            page_name = p.get("name", "")
                            # We no longer skip changelog pages here — they're
                            # extracted separately above. But if a changelog page
                            # ended up inside a version group, still skip it
                            # (it's not requirement content).
                            if _is_changelog_page(page_name):
                                continue

                            filename = p.get("filename", f'{page_name}.html')
                            html_path = Path(resource_dir) / filename
                            if html_path.exists():
                                text = _extract_page_text(html_path)
                                if text:
                                    # Add per-page client scope hint
                                    page_clients = _detect_client_scope(page_name)
                                    page_client_tag = ""
                                    if page_clients and page_clients != vg_clients:
                                        page_client_tag = f" [{'/'.join(page_clients)}端]"

                                    entry = f"### {page_name}{page_client_tag}\n\n{text}"
                                    entry_chars = len(entry)
                                    if vg_chars + entry_chars > per_version_budget:
                                        vg_truncated = True
                                        remaining = per_version_budget - vg_chars
                                        if remaining > 200:
                                            vg_texts.append(
                                                f"### {page_name}\n\n{text[:remaining]}..."
                                                f"(内容已截断)"
                                            )
                                        break
                                    vg_texts.append(entry)
                                    vg_chars += entry_chars
                                else:
                                    total_empty += 1
                            else:
                                total_empty += 1

                        if vg_texts:
                            section = (
                                f"## 版本: {vg_name}{client_hint}\n\n"
                                + "\n\n".join(vg_texts)
                            )
                            version_sections.append(section)
                            total_extracted += len(vg_texts)
                            extracted_version_count += 1
                            if vg_truncated:
                                total_truncated = True

                    # Build version-aware summary with changelog info
                    vg_names = [vg["name"] for vg in structure["version_groups"]]
                    summary_parts = [
                        f"# 蓝湖设计稿「{doc_name}」版本化提取：\n"
                        f"共识别 {len(structure['version_groups'])} 个版本分组"
                        f"（{' / '.join(vg_names)}），",
                        f"已提取 {extracted_version_count} 个版本共 {total_extracted} 页"
                        f"（全文档共 {full_page_count} 页）",
                    ]
                    if detected_clients:
                        summary_parts.append(f"，涉及端: {'/'.join(detected_clients)}")
                    summary_parts.append(
                        (f"，更新日志 {len(structure['changelog_pages'])} 页" if structure["changelog_pages"] else "")
                        + (f"，{total_empty} 页无文本内容" if total_empty else "")
                        + ("，内容已截断" if total_truncated else "")
                        + "。\n"
                    )
                    summary = "".join(summary_parts)

                    if version_sections:
                        # Prepend changelog content if available
                        content_parts = [summary]
                        if changelog_content:
                            content_parts.append(
                                "\n\n# 版本更新日志（用于版本识别和需求溯源）\n\n"
                                + changelog_content
                                + "\n\n---\n\n# 各版本需求内容\n"
                            )
                        content_parts.append("\n\n".join(version_sections))
                        content_parts.append(f"\n\n---\n蓝湖链接: {effective_url}")

                        content = "\n".join(content_parts)
                        return {
                            "content": content,
                            "page_filtered": False,
                            "folder_name": "",
                            "changelog": {"raw": changelog_content} if changelog_content else None,
                            "client_scope": detected_clients,
                        }
                    else:
                        raise ValueError(
                            f"蓝湖设计稿「{doc_name}」共 {full_page_count} 页，"
                            f"识别到 {len(structure['version_groups'])} 个版本分组，"
                            f"但未能提取到有效的页面文本内容"
                            + (f"（{total_empty} 个页面无文本或HTML文件缺失）" if total_empty else "")
                            + "。请检查蓝湖链接是否正确，或原型页面是否包含可提取的文本内容。"
                        )

            # ── Flat extraction (no version structure or page-filtered) ──
            effective_max_chars = _MAX_EXTRACTED_CHARS
            if page_filtered:
                effective_max_chars = _MAX_EXTRACTED_CHARS * 4
            else:
                page_based = min(len(all_pages) * 2000, _MAX_EXTRACTED_CHARS * 3)
                effective_max_chars = max(_MAX_EXTRACTED_CHARS, page_based)

            page_texts: list[str] = []
            skipped_changelog: list[str] = []
            empty_pages: list[str] = []
            total_chars = 0
            truncated = False

            # If we have changelog content from version-aware analysis but
            # fell through to flat extraction, prepend it
            if changelog_content and not page_filtered:
                page_texts.append(
                    "# 版本更新日志（用于版本识别和需求溯源）\n\n"
                    + changelog_content
                    + "\n\n---\n\n# 需求内容\n"
                )
                total_chars = len(page_texts[0])

            for p in all_pages:
                page_name = p.get("name", "")
                # In flat extraction, skip changelog pages (already extracted above)
                if _is_changelog_page(page_name):
                    skipped_changelog.append(page_name)
                    continue

                filename = p.get("filename", f'{page_name}.html')
                html_path = Path(resource_dir) / filename
                if html_path.exists():
                    text = _extract_page_text(html_path)
                    if text:
                        entry = f"## {page_name}\n\n{text}"
                        entry_chars = len(entry)
                        if total_chars + entry_chars > effective_max_chars:
                            truncated = True
                            remaining = effective_max_chars - total_chars
                            if remaining > 200:
                                page_texts.append(f"## {page_name}\n\n{text[:remaining]}...(内容已截断)")
                            break
                        page_texts.append(entry)
                        total_chars += entry_chars
                    else:
                        empty_pages.append(page_name)
                else:
                    empty_pages.append(page_name)

            # Build summary
            if page_filtered:
                summary_parts = [
                    f"蓝湖设计稿「{doc_name}」-> 「{folder_name}」模块提取："
                ]
                summary_parts.append(
                    f"模块共 {len(all_pages)} 页（全文档共 {full_page_count} 页），"
                    f"已提取 {len(page_texts)} 页"
                )
            else:
                summary_parts = [f"蓝湖设计稿「{doc_name}」内容提取："]
                summary_parts.append(
                    f"共 {len(all_pages)} 页，已提取 {len(page_texts)} 页"
                )
            if detected_clients:
                summary_parts.append(f"，涉及端: {'/'.join(detected_clients)}")
            summary_parts.append(
                (f"，更新日志 {len(skipped_changelog)} 页（已优先提取）" if skipped_changelog else "")
                + (f"，{len(empty_pages)} 页无文本内容" if empty_pages else "")
                + ("，内容已截断" if truncated else "")
                + "。\n"
            )
            summary = "".join(summary_parts)

            if page_texts:
                return {
                    "content": summary + "\n\n---\n\n".join(page_texts) + f"\n\n---\n蓝湖链接: {effective_url}",
                    "page_filtered": page_filtered,
                    "folder_name": folder_name,
                    "changelog": {"raw": changelog_content} if changelog_content else None,
                    "client_scope": detected_clients,
                }
            else:
                raise ValueError(
                    f"蓝湖设计稿「{doc_name}」共 {full_page_count} 页，"
                    f"但未能提取到有效的页面文本内容"
                    + (f"（{len(empty_pages)} 个页面无文本或HTML文件缺失）" if empty_pages else "")
                    + "。请检查蓝湖链接是否正确，或原型页面是否包含可提取的文本内容。"
                )

        # Try extraction with current cookie
        try:
            return await _do_extract(page_id=_page_id)
        except Exception as e:
            is_auth = (isinstance(e, runtime.auth_error_types)
                       or _is_lanhu_session_expired(e))
            if not is_auth:
                raise
            if not auto_login or runtime.login is None:
                raise ValueError(
                    f"蓝湖认证失败，Cookie 已过期或已被拒绝（HTTP 418 表示会话失效）。"
                    f"请重新登录或手动获取 Cookie 填入 LANHU_COOKIE。\n"
                    f"错误详情: {str(e)[:200]}"
                )
            logger.warning("[ai_service] Lanhu auth failed: %s. Attempting auto-login...", e)
            try:
                new_cookie = await _login_lanhu_with_retry(runtime)
                _persist_lanhu_cookie(new_cookie, runtime)
                logger.info("[ai_service] Auto-login succeeded, retrying extraction with new cookie...")
                return await _do_extract(cookie_override=new_cookie, page_id=_page_id)
            except runtime.auth_error_types as login_err:
                raise ValueError(
                    f"蓝湖自动登录失败: {str(login_err)[:200]}。"
                    f"请检查 .env 中的 LANHU_USERNAME 和 LANHU_PASSWORD 是否正确，"
                    f"或手动获取 Cookie 填入 LANHU_COOKIE。"
                )
            except ValueError as login_err:
                raise ValueError(
                    f"蓝湖自动登录失败：{str(login_err)[:200]}。"
                    f"请配置 LANHU_USERNAME/LANHU_PASSWORD 或手动获取 Cookie 填入 LANHU_COOKIE。"
                )
            except Exception as login_err:
                raise ValueError(
                    f"蓝湖自动登录时发生未知错误: {str(login_err)[:200]}。"
                    f"请手动获取 Cookie 填入 LANHU_COOKIE。"
                )

    except ValueError:
        raise
    except Exception as e:
        raise ValueError(
            f"蓝湖设计稿内容提取失败: {str(e)[:300]}。"
            f"请检查蓝湖链接是否有效，或稍后重试。"
        )
    finally:
        if str(_lanhu_mcp_dir()) in sys.path:
            sys.path.remove(str(_lanhu_mcp_dir()))


# ── 标准化 Provider 接口（供需求 / 知识中心 Raw Source / Wiki 编译复用）──

_AUTH_HINTS = ("登录", "LANHU_USERNAME", "LANHU_PASSWORD", "LANHU_COOKIE", "cookie", "认证", "登录态")
_PERM_HINTS = ("无权", "权限不足", "没有权限", "permission")
_IMAGE_HINTS = ("图片", "补充说明", "无法提取", "image", "无文本")
_PARTIAL_HINTS = ("部分", "partial")
_INVALID_URL_HINTS = ("docId", "pageId", "文档链接", "项目链接", "设计稿页面")


def _classify_error_status(msg: str) -> str:
    """把原始提取抛出的 ValueError 文案归类为标准 extraction_status。"""
    text = msg or ""
    if any(h in text for h in _AUTH_HINTS):
        return "auth_failed"
    if any(h in text for h in _PERM_HINTS):
        return "permission_denied"
    if any(h in text for h in _IMAGE_HINTS):
        return "image_only"
    if any(h in text for h in _INVALID_URL_HINTS):
        return "invalid_url"
    return "failed"


def parse_lanhu_ids(url: str) -> tuple[str, str, str]:
    """从蓝湖 URL 解析 docId / versionId / pageId（本地正则，不触网）。

    Returns (doc_id, version_id, page_id). page_id 为可选——当 URL 不含 pageId 时
    表示整文档导入。
    """
    def _grab(param: str) -> str:
        m = re.search(param + r"=([^&#]+)", url or "")
        return m.group(1) if m else ""
    return _grab("docId"), _grab("versionId"), _grab("pageId")


# 向后兼容别名：旧调用方仍可使用 _parse_url_ids
_parse_url_ids = parse_lanhu_ids


async def _resolve_project_doc(url: str, extractor) -> tuple[str, str]:
    """项目级蓝湖链接（仅 tid+pid，无 docId）→ 自动发现首个设计文档。

    Returns (effective_url, doc_id)：effective_url 为原链接追加 docId 后的可下载
    URL。项目内无文档或接口异常时抛 ValueError（明确提示，而非「缺少 docId」）。
    供需求提取 `_extract_lanhu_content` 与证据包 `get_lanhu_pages_for_evidence`
    共享，保证两条链路行为一致（C87-1）。
    """
    params = extractor.parse_url(url)
    team_id = params.get("team_id", "")
    project_id = params.get("project_id", "")
    if not project_id:
        raise ValueError(
            "蓝湖链接缺少项目 ID（pid），请在蓝湖打开具体设计稿后复制含 docId 的链接"
        )
    logger.info(
        "[lanhu_provider] No docId in URL (tid=%s..., pid=%s...)",
        str(team_id)[:8], str(project_id)[:8],
    )
    try:
        resp = await extractor.client.get(
            "https://lanhuapp.com/api/project/images"
            f"?project_id={project_id}&team_id={team_id}"
            "&dds_status=1&position=1&show_cb_src=1&comment=1"
        )
        if resp.status_code == 200:
            data = resp.json()
            if data.get("code") == "00000":
                images = data.get("data", {}).get("images", [])
                if images:
                    doc_id = str(images[0].get("id") or "")
                    doc_name_hint = str(images[0].get("name") or "")
                    sep = "&" if "?" in url.split("#")[-1] else "?"
                    effective_url = f"{url}{sep}docId={doc_id}"
                    logger.info(
                        "[lanhu_provider] Auto-selected document: '%s' (id=%s...)",
                        doc_name_hint, doc_id[:16],
                    )
                    return effective_url, doc_id
    except Exception as exc:  # noqa: BLE001 — 统一转为明确错误
        logger.warning("[lanhu_provider] project images discovery failed: %s", exc)
    raise ValueError(
        "蓝湖项目内未发现设计文档，请在蓝湖打开具体设计稿后复制含 docId 的链接"
    )


async def _get_design_board_pages(url: str, extractor, resource_dir: str) -> dict | None:
    """设计图板项目（项目级链接，无 docId）→ 下载全部设计图 + 批注卡为证据页面。

    `/api/project/images` 返回项目设计图板：type=image 为设计图（url 直链下载），
    type=card 为批注卡（文字在 name 字段）。设计图以原图文件作为证据页；
    批注卡写成本地 HTML 页（保留真实批注文字），统一走截图/OCR/质量门禁。
    项目内无下载设计图时返回 None，交由文档发现流程处理。
    """
    params = extractor.parse_url(url)
    project_id = params.get("project_id")
    team_id = params.get("team_id")
    if not project_id or not team_id:
        return None
    resp = await extractor.client.get(
        "https://lanhuapp.com/api/project/images"
        f"?project_id={project_id}&team_id={team_id}"
        "&dds_status=1&position=1&show_cb_src=1&comment=1"
    )
    if resp.status_code != 200:
        return None
    data = resp.json()
    if data.get("code") != "00000":
        return None
    images = (data.get("data") or {}).get("images") or []
    image_items = [im for im in images if im.get("type") == "image" and im.get("url")]
    if not image_items:
        return None

    logger.info(
        "[lanhu_provider] Design board discovered: %d images, %d cards (pid=%s...)",
        len(image_items),
        sum(1 for im in images if im.get("type") == "card"),
        str(project_id)[:8],
    )
    board_dir = Path(resource_dir) / "design"
    board_dir.mkdir(parents=True, exist_ok=True)
    pages: list[dict] = []
    for order, im in enumerate(image_items):
        image_id = str(im.get("id") or f"img-{order:03d}")
        image_name = str(im.get("name") or image_id)
        local = board_dir / f"{image_id}.png"
        try:
            resp_img = await extractor.client.get(str(im.get("url")))
            if resp_img.status_code == 200 and resp_img.content:
                local.write_bytes(resp_img.content)
        except Exception as exc:  # noqa: BLE001 — 单图失败不阻断整板
            logger.warning("[lanhu_provider] design image download failed %s: %s", image_id[:12], exc)
        pages.append({
            "id": image_id,
            "name": image_name,
            "path": f"设计图板/{image_name}",
            "folder": "设计图板",
            "filename": local.name,
            "local_url": local.as_uri() if local.exists() else "",
        })

    card_dir = Path(resource_dir) / "cards"
    card_dir.mkdir(parents=True, exist_ok=True)
    for order, card in enumerate(images):
        if card.get("type") != "card":
            continue
        card_id = str(card.get("id") or f"card-{order:03d}")
        text = str(card.get("name") or "").strip()
        if not text:
            continue
        html_path = card_dir / f"{card_id}.html"
        html_path.write_text(
            "<!DOCTYPE html><html><head><meta charset='utf-8'>"
            "<style>body{font-family:sans-serif;padding:24px;"
            "white-space:pre-wrap;font-size:16px;line-height:1.6;}</style>"
            f"</head><body>{html.escape(text)}</body></html>",
            encoding="utf-8",
        )
        pages.append({
            "id": card_id,
            "name": text[:40],
            "path": f"设计批注/{text[:40]}",
            "folder": "设计批注",
            "filename": html_path.name,
            "local_url": html_path.as_uri(),
        })

    return {
        "status": "success",
        "resource_dir": str(resource_dir),
        "document_name": "蓝湖设计图板",
        "pages": pages,
    }


def build_immutable_version(doc_id: str, version_id: str, page_id: str | None) -> str:
    """构建标准化的蓝湖 immutable_version。

    格式: lanhu:{docId}:{versionId}:{pageId}
    page_id 为空时省略末尾段: lanhu:{docId}:{versionId}

    示例:
        build_immutable_version("doc-123", "ver-456", "page-789")
        -> "lanhu:doc-123:ver-456:page-789"

        build_immutable_version("doc-123", "ver-456", None)
        -> "lanhu:doc-123:ver-456"
    """
    parts = [p for p in (doc_id, version_id, page_id) if p]
    return "lanhu:" + ":".join(parts)


async def extract(url: str, auto_login: bool = True):
    """标准化蓝湖提取入口。

    永不抛异常：所有失败以 LanhuExtractResult.extraction_status 表达
    （success/partial/image_only/auth_failed/permission_denied/invalid_url/failed），
    便于需求模块、知识中心、Wiki 统一按状态提示与入库。
    """
    from app.schemas.lanhu import LanhuExtractResult

    doc_id, version_id, page_id = _parse_url_ids(url)
    if not doc_id and not page_id:
        return LanhuExtractResult(
            source_ref=url, doc_id=doc_id, version_id=version_id, page_id=page_id,
            extraction_status="invalid_url",
            extraction_summary="链接缺少 docId/pageId，请复制具体设计稿页面链接",
        )

    try:
        raw = await _extract_lanhu_content(url, auto_login=auto_login)
    except ValueError as e:
        return LanhuExtractResult(
            source_ref=url, doc_id=doc_id, version_id=version_id, page_id=page_id,
            extraction_status=_classify_error_status(str(e)),
            extraction_summary=str(e)[:500],
        )
    except Exception as e:  # noqa: BLE001 — 兜底，绝不影响调用方
        return LanhuExtractResult(
            source_ref=url, doc_id=doc_id, version_id=version_id, page_id=page_id,
            extraction_status="failed", extraction_summary=str(e)[:500],
        )

    content = (raw.get("content") or "").strip()
    folder_name = raw.get("folder_name") or ""
    client_scope = raw.get("client_scope") or []
    changelog = raw.get("changelog") or {}
    content_hash = hashlib.sha256(content.encode("utf-8")).hexdigest() if content else ""
    if doc_id:
        immutable_version = build_immutable_version(doc_id, version_id, page_id or None)
    else:
        immutable_version = content_hash  # 非蓝湖来源退化为 content_hash

    if not content:
        status, summary = "image_only", "原型无可提取文本（可能为图片），请填写补充说明"
    else:
        scope_txt = "/".join(client_scope) if client_scope else "未标注端"
        # partial: 提取成功但部分页面无文本（content 中包含「无文本内容」提示）
        if "无文本内容" in content or "页面无文本" in content:
            status = "partial"
        else:
            status = "success"
        summary = f"提取成功，约 {len(content)} 字，模块「{folder_name or '未分组'}」，端范围 {scope_txt}"

    return LanhuExtractResult(
        source_ref=url,
        doc_id=doc_id, version_id=version_id, page_id=page_id,
        module_name=folder_name,
        client_scope=client_scope,
        changelog=changelog,
        content_md=content,
        content_hash=content_hash,
        immutable_version=immutable_version,
        extraction_status=status,
        extraction_summary=summary,
    )


# ── 证据包专用：下载资源 + 返回全页面树（供滚动截图与 OCR）──

_VERSION_FOLDER_RE = re.compile(r"^v?\d+(\.\d+){1,2}$", re.IGNORECASE)


def _version_sort_key(name: str):
    """语义版本排序键：提取数字段。"""
    return tuple(int(x) for x in re.findall(r"\d+", name)[:3])


def _filter_latest_version_pages(pages: list[dict]) -> list[dict]:
    """仅保留"最新版本文件夹"下的页面（顶层路径段如 16.0.0）。

    若没有版本样式文件夹（如设计图板/单文档），返回全部页面兜底。
    """
    if not pages:
        return pages
    groups: dict[str, list[dict]] = {}
    for page in pages:
        top = str(page.get("folder") or page.get("path") or "").split("/")[0]
        groups.setdefault(top, []).append(page)
    version_folders = [name for name in groups if _VERSION_FOLDER_RE.match(name)]
    if not version_folders:
        return pages
    latest = max(version_folders, key=_version_sort_key)
    logger.info("[lanhu_provider] latest_version_only: keep folder '%s' (%d/%d pages)",
                latest, len(groups[latest]), len(pages))
    return groups[latest]


async def get_lanhu_pages_for_evidence(url: str, latest_version_only: bool = False, capture_all_pages: bool = True) -> dict:
    """下载 Axure 资源并返回全页面列表，供证据包截图/OCR 使用。

    与 `_extract_lanhu_content` 共用下载与认证重试逻辑，但不做文本聚合：
    只返回 resource_dir、document_name 和规范化 pages（含 filename / folder /
    local_url），让 screenshot_service 逐页滚动截图、OCR。

    Return:
        {"status": "success", "resource_dir": str, "document_name": str,
         "pages": [{"id","name","path","folder","filename","local_url"}, ...]}
    异常统一以 status="failed" + error 表达，绝不裸抛。
    """
    sys.path.insert(0, str(_lanhu_mcp_dir()))
    try:
        runtime = _load_lanhu_runtime()

        async def _do(cookie_override: str = "") -> dict:
            if not cookie_override:
                cookie_override = get_lanhu_cookie()
            extractor = _create_lanhu_extractor(runtime, cookie_override)
            params = extractor.parse_url(url)
            doc_id = params.get("doc_id", "")
            url_version_id = params.get("version_id", "")
            effective_url = url
            if not doc_id:
                # C87-1: 项目级链接（仅 tid+pid）→ 优先设计图板（原图下载+OCR）
                project_id = params.get("project_id", "")
                board = await _get_design_board_pages(
                    url, extractor,
                    str(_data_dir() / f"design_board_{str(project_id)[:8]}"),
                )
                if board is not None:
                    return board
                # 无设计图板 → 文档自动发现
                effective_url, doc_id = await _resolve_project_doc(url, extractor)
                params = extractor.parse_url(effective_url)
                url_version_id = params.get("version_id", "")

            resource_dir = str(_data_dir() / f"axure_extract_{doc_id[:8]}")
            # Batch 159：capture_all_pages=False 且带 pageId 时走「页面列表优先 + 有界下载」，
            # 只下载目标页/同文件夹资源；全量路径保持原有顺序（先下载，受限下载不继续生成页面证据）。
            if capture_all_pages or not params.get("page_id"):
                download_result = await _download_lanhu_resources(
                    extractor,
                    effective_url,
                    resource_dir,
                    url_version_id,
                    params.get("page_id", ""),
                )
                _ensure_download_is_usable(download_result)
                if download_result.get("status") in ("downloaded", "updated"):
                    runtime.fix_html_files(resource_dir)
                pages_info = await extractor.get_pages_list(effective_url)
            else:
                pages_info = await extractor.get_pages_list(effective_url)
                download_result = await _download_lanhu_resources_scoped(
                    extractor,
                    effective_url,
                    resource_dir,
                    params,
                    pages_info,
                    cdn_url=str(getattr(runtime.module, "CDN_URL", "") or ""),
                    target_page_id=params.get("page_id", ""),
                    capture_all_pages=False,
                )
                if download_result is None:
                    download_result = await _download_lanhu_resources(
                        extractor,
                        effective_url,
                        resource_dir,
                        url_version_id,
                        params.get("page_id", ""),
                    )
                _ensure_download_is_usable(download_result)
                if download_result.get("status") in ("downloaded", "updated"):
                    runtime.fix_html_files(resource_dir)

            document_name = pages_info.get("document_name", "设计稿")

            raw_pages = pages_info.get("pages", [])
            if latest_version_only:
                raw_pages = _filter_latest_version_pages(raw_pages)
            pages: list[dict] = []
            for p in raw_pages:
                name = p.get("name", "")
                folder = p.get("folder", "")
                filename = p.get("filename", f"{name}.html")
                path = f"{folder}/{name}" if folder else name
                html_path = Path(resource_dir) / filename
                local_url = html_path.as_uri() if html_path.exists() else ""
                pages.append({
                    "id": p.get("id", ""),
                    "name": name,
                    "path": path,
                    "folder": folder,
                    "filename": filename,
                    "local_url": local_url,
                })

            return {
                "status": "success",
                "resource_dir": resource_dir,
                "document_name": document_name,
                "pages": pages,
            }

        async def _do_with_retry() -> dict:
            """Batch 159：整体超时兜底 + 瞬时失败重试一次（大版本下载易触发 30s 单请求超时）。"""
            last: BaseException | None = None
            for attempt in range(2):
                try:
                    return await asyncio.wait_for(
                        _do(), timeout=_LANHU_EVIDENCE_TIMEOUT_SECONDS,
                    )
                except (asyncio.TimeoutError, httpx.TimeoutException, httpx.TransportError) as exc:
                    last = exc
                    logger.warning(
                        "[lanhu_provider] evidence download attempt %s failed: %s",
                        attempt + 1, str(exc) or type(exc).__name__,
                    )
                    continue
            raise last  # type: ignore[misc]

        try:
            return await _do_with_retry()
        except Exception as exc:
            is_auth = (isinstance(exc, runtime.auth_error_types)
                       or _is_lanhu_session_expired(exc))
            if not is_auth:
                raise
            if runtime.login is None:
                return {
                    "status": "failed",
                    "error": "蓝湖会话已失效（Cookie 过期或 HTTP 418 被拒），请重新登录或更新 LANHU_COOKIE",
                    "manual_action_required": True,
                    "pages": [],
                }
            try:
                new_cookie = await _login_lanhu_with_retry(runtime)
            except ValueError as login_err:
                return {
                    "status": "failed",
                    "error": f"蓝湖会话失效且自动登录失败：{str(login_err)[:200]}。请重新登录或更新 LANHU_COOKIE",
                    "manual_action_required": True,
                    "pages": [],
                }
            _persist_lanhu_cookie(new_cookie, runtime)
            return await _do(cookie_override=new_cookie)
    except LanhuManualActionRequired as e:
        return {
            "status": "failed",
            "error": (str(e) or type(e).__name__),
            "manual_action_required": True,
            "pages": [],
        }
    except Exception as e:  # noqa: BLE001 — 统一以状态表达失败
        return {"status": "failed", "error": (str(e) or type(e).__name__)[:300], "pages": []}
    finally:
        if str(_lanhu_mcp_dir()) in sys.path:
            sys.path.remove(str(_lanhu_mcp_dir()))
