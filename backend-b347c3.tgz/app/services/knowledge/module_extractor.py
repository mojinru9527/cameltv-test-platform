"""ModuleExtractor — 从蓝湖证据包提取层级结构 (模块→页面→功能点)

Heuristic-based extraction from LanhuEvidencePage data:
  1. URL parentId relationships → page hierarchy
  2. Page name patterns → changelog_entry detection
  3. Folder name → platform classification
  4. AI-assisted module boundary detection (stub)

Output: list of ModuleTreeNode ready for RequirementModule creation.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.lanhu_evidence import LanhuEvidenceJob, LanhuEvidencePage
from app.models.requirement import RequirementDocument

logger = logging.getLogger("knowledge.module_extractor")


# ── Dataclasses ──

@dataclass
class FunctionPoint:
    """A feature-level function point within a page."""
    name: str
    description: str = ""
    category: str = ""  # e.g., CRUD, filter, navigation, display
    related_interactions: list[str] = field(default_factory=list)


@dataclass
class PageNode:
    """A page node within a module."""
    name: str
    lanhu_page_id: str = ""
    folder: str = ""
    order_index: int = 0
    ocr_text: str = ""
    screenshot_url: str = ""
    function_points: list[FunctionPoint] = field(default_factory=list)
    child_pages: list[PageNode] = field(default_factory=list)  # nested sub-pages


@dataclass
class ModuleNode:
    """A module node in the extracted tree."""
    name: str
    platform: str = ""  # APP | PC | WEB | ADMIN
    node_type: str = "module"  # module | changelog | attachment
    description: str = ""
    lanhu_folder: str = ""
    sort_order: int = 0
    pages: list[PageNode] = field(default_factory=list)
    attachments: list[str] = field(default_factory=list)  # attachment file names/URLs


@dataclass
class ExtractionResult:
    """Complete extraction output."""
    modules: list[ModuleNode] = field(default_factory=list)
    changelog_entries: list[dict] = field(default_factory=list)
    attachments: list[dict] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    stats: dict = field(default_factory=dict)


# ── Heuristics ──

# Known attachment folder names (说明附件)
_ATTACHMENT_FOLDER_PATTERNS = [
    "说明附件", "附件", "说明文档", "参考文档",
    "attachment", "docs", "reference",
]

# Known changelog page patterns
_CHANGELOG_PATTERNS = [
    "更新日志", "版本历史", "changelog", "release notes",
    "版本记录", "更新记录",
]

# Platform folder patterns
_PLATFORM_PATTERNS = {
    "APP": ["app端", "app", "客户端", "移动端app", "android", "ios"],
    "PC": ["pc端", "pc", "电脑端", "桌面端", "浏览器端", "pc浏览器"],
    "WEB": ["web端", "web", "h5", "移动端h5", "手机端", "m站"],
    "ADMIN": ["运营后台", "后台", "管理后台", "admin", "管理端", "运营端"],
}


def _normalize(text: str) -> str:
    return (text or "").strip().lower()


def _is_changelog(name: str) -> bool:
    n = _normalize(name)
    return any(p in n for p in _CHANGELOG_PATTERNS)


def _is_attachment_folder(name: str) -> bool:
    n = _normalize(name)
    return any(p in n for p in _ATTACHMENT_FOLDER_PATTERNS)


def _infer_platform(folder: str, page_path: str = "") -> str:
    """Infer platform from folder name or page path."""
    combined = _normalize(folder) + " " + _normalize(page_path)
    for platform, patterns in _PLATFORM_PATTERNS.items():
        if any(p in combined for p in patterns):
            return platform
    return ""


def _extract_folder_name(page_path: str) -> str:
    """Extract the top-level folder name from a page path like 'APP端/资讯/资讯列表'."""
    if not page_path:
        return ""
    parts = page_path.replace("\\", "/").split("/")
    # First non-empty part that isn't the page itself
    if len(parts) >= 2:
        return parts[0]
    return ""


# ── Main Extractor ──

def ai_boundary_suggestions_sync(
    db: Session,
    project_id: int,
    folder_pages: list[tuple[str, int]],
    model_ref: str | None = None,
) -> list[dict]:
    """Batch 208 (C7): AI-assisted module boundary suggestions (opt-in).

    Sends the folder -> page-count inventory to the configured model and
    returns ``[{folder, merge_into, reason}]``. When AI is not configured or
    the call fails it returns [] and never changes deterministic behaviour.
    """
    from app.services import ai_client

    if not ai_client.is_configured(db, project_id):
        return []
    inventory = [
        {"folder": folder, "page_count": count}
        for folder, count in folder_pages
    ]
    system = (
        "你是需求模块边界分析师。根据设计稿文件夹清单判断哪些文件夹其实是同一"
        "业务模块被拆散。只输出 JSON：{\"suggestions\": [{\"folder\": \"原始目录\", "
        "\"merge_into\": \"应合并到的模块名\", \"reason\": \"一句话理由\"}]}。"
        "没有把握就不要建议，不臆造。"
    )
    try:
        payload = ai_client.chat_completions(
            db,
            project_id,
            system_prompt=system,
            user_message=json.dumps(
                {"folders": inventory, "model_ref": model_ref},
                ensure_ascii=False,
            ),
            max_tokens=2048,
            json_mode=True,
        )
    except (ai_client.AiClientUnavailableError, ai_client.AiClientResponseError):
        return []
    items = payload.get("suggestions") if isinstance(payload, dict) else None
    if not isinstance(items, list):
        return []
    out = []
    for item in items:
        if not isinstance(item, dict):
            continue
        folder = str(item.get("folder") or "").strip()
        target = str(item.get("merge_into") or "").strip()
        if folder and target:
            out.append(
                {
                    "folder": folder,
                    "merge_into": target,
                    "reason": str(item.get("reason") or "")[:200],
                }
            )
    return out


def extract_module_tree(
    db: Session,
    *,
    evidence_job_id: int,
    project_id: int,
    document_id: int | None = None,
    boundary_suggestions: list[dict] | None = None,
) -> ExtractionResult:
    """Extract hierarchical module tree from Lanhu evidence pages.

    Algorithm:
      1. Load all pages from the evidence job.
      2. Classify each page: changelog, attachment, or regular module page.
      3. Group regular pages by their top-level folder (≈ module).
      4. Within each module, sort pages by order_index.
      5. Infer platform per module via folder heuristics.
      6. Build ModuleNode tree.
    """
    result = ExtractionResult()

    # Load evidence job
    job = db.get(LanhuEvidenceJob, evidence_job_id)
    if not job:
        result.warnings.append(f"Evidence job #{evidence_job_id} not found")
        return result

    # Load all pages
    pages = list(
        db.scalars(
            select(LanhuEvidencePage)
            .where(LanhuEvidencePage.job_id == evidence_job_id)
            .order_by(LanhuEvidencePage.order_index)
        ).all()
    )

    if not pages:
        result.warnings.append(f"No pages found in evidence job #{evidence_job_id}")
        return result

    # Load document for platform hint
    document = db.get(RequirementDocument, document_id) if document_id else None
    doc_platform = document.platform if document else ""

    # ── Classify pages ──
    changelog_pages: list[LanhuEvidencePage] = []
    attachment_pages: list[LanhuEvidencePage] = []
    module_pages: list[LanhuEvidencePage] = []

    for page in pages:
        folder = page.folder or _extract_folder_name(page.page_path)
        if _is_changelog(page.page_name) or _is_changelog(folder):
            changelog_pages.append(page)
        elif _is_attachment_folder(folder):
            attachment_pages.append(page)
        else:
            module_pages.append(page)

    # ── Process changelog entries ──
    for page in changelog_pages:
        result.changelog_entries.append({
            "page_name": page.page_name,
            "page_id": page.page_id,
            "folder": page.folder,
            "ocr_text": page.merged_text or page.ocr_text or "",
            "screenshot_url": page.local_url or "",
        })

    # ── Process attachments ──
    for page in attachment_pages:
        result.attachments.append({
            "file_name": page.page_name,
            "folder": page.folder,
            "page_id": page.page_id,
            "screenshot_url": page.local_url or "",
            "ocr_text": page.merged_text or page.ocr_text or "",
        })

    # ── Group module pages by folder ──
    pages_by_folder: dict[str, list[LanhuEvidencePage]] = {}
    for page in module_pages:
        folder = page.folder or _extract_folder_name(page.page_path) or "__root__"
        pages_by_folder.setdefault(folder, []).append(page)

    # ── Build module tree ──
    for folder, folder_pages in sorted(pages_by_folder.items()):
        # Determine platform
        platform = _infer_platform(folder) or doc_platform

        # Skip if folder is actually a platform-level container
        if folder in ("__root__",) and len(pages_by_folder) == 1:
            # Single folder — try to infer structure from page paths
            pass

        module = ModuleNode(
            name=folder,
            platform=platform,
            node_type="module",
            lanhu_folder=folder,
            sort_order=folder_pages[0].order_index if folder_pages else 0,
        )

        # Build page hierarchy within module
        # Nested pages: pages whose page_path has additional segments after the folder
        top_pages: dict[str, PageNode] = {}
        sub_pages: list[tuple[str, PageNode]] = []  # (parent_name, page_node)

        for page in sorted(folder_pages, key=lambda p: p.order_index):
            page_path_parts = (page.page_path or "").replace("\\", "/").split("/")
            # Determine if this is a nested page
            if len(page_path_parts) >= 3 and _normalize(page_path_parts[0]) == _normalize(folder):
                # Nested: folder/subfolder/page_name
                parent_name = page_path_parts[1] if len(page_path_parts) >= 3 else ""
                pn = PageNode(
                    name=page.page_name,
                    lanhu_page_id=page.page_id,
                    folder=page.folder,
                    order_index=page.order_index,
                    ocr_text=page.merged_text or page.ocr_text or "",
                    screenshot_url=page.local_url or "",
                )
                if parent_name and parent_name != page.page_name:
                    sub_pages.append((parent_name, pn))
                else:
                    top_pages[page.page_name] = pn
            else:
                pn = PageNode(
                    name=page.page_name,
                    lanhu_page_id=page.page_id,
                    folder=page.folder,
                    order_index=page.order_index,
                    ocr_text=page.merged_text or page.ocr_text or "",
                    screenshot_url=page.local_url or "",
                )
                top_pages[page.page_name] = pn

        # Merge sub-pages into parent pages
        for parent_name, child in sub_pages:
            if parent_name in top_pages:
                top_pages[parent_name].child_pages.append(child)
            else:
                # Create parent placeholder
                parent = PageNode(name=parent_name)
                parent.child_pages.append(child)
                top_pages[parent_name] = parent

        module.pages = list(top_pages.values())
        result.modules.append(module)

    # ── AI boundary suggestions (Batch 208, C7, opt-in) ──
    if boundary_suggestions:
        by_folder = {m.lanhu_folder or m.name: m for m in result.modules}
        for suggestion in boundary_suggestions:
            folder = str(suggestion.get("folder") or "")
            target = str(suggestion.get("merge_into") or "").strip()
            module = by_folder.get(folder)
            if not module or not target or module.name == target:
                continue
            if any(m.name == target for m in result.modules if m is not module):
                continue
            module.name = target
            result.warnings.append(
                f"AI boundary: folder {folder} -> {target}"
            )

    # ── Stats ──
    result.stats = {
        "total_pages": len(pages),
        "total_modules": len(result.modules),
        "changelog_entries": len(result.changelog_entries),
        "attachment_files": len(result.attachments),
        "module_pages": len(module_pages),
    }

    # ── Accuracy (C27-C1: target ≥70%) ──
    accuracy = _compute_accuracy(result)
    result.stats.update(accuracy)

    logger.info(
        "Module extraction complete: %d modules, %d pages, %d changelog entries, %d attachments, accuracy=%.1f%%",
        result.stats["total_modules"],
        result.stats["module_pages"],
        result.stats["changelog_entries"],
        result.stats["attachment_files"],
        result.stats.get("overall_score", 0) * 100,
    )

    return result


# ── Accuracy measurement (C27-C1: target ≥70%) ──

def _compute_accuracy(result: ExtractionResult) -> dict:
    """Compute extraction accuracy metrics.

    Measures three dimensions and combines into an overall score:
      1. Platform inference rate: modules with non-empty platform / total modules
      2. Classification precision: pages correctly classified (not ambiguous)
      3. Module granularity: balanced modules (not too few/too many per module)

    Target: overall_score ≥ 0.70 (70%).
    """
    stats: dict = {
        "platform_accuracy": 0.0,
        "classification_rate": 0.0,
        "module_granularity_score": 0.0,
        "overall_score": 0.0,
    }

    total_modules = len(result.modules)
    total_pages = result.stats.get("total_pages", 0)
    module_pages = result.stats.get("module_pages", 0)

    # 1. Platform inference rate: how many modules have a non-empty platform
    if total_modules > 0:
        modules_with_platform = sum(1 for m in result.modules if m.platform)
        stats["platform_accuracy"] = modules_with_platform / total_modules
    else:
        stats["platform_accuracy"] = 0.0

    # 2. Classification rate: pages classified into module/changelog/attachment
    if total_pages > 0:
        classified = module_pages + result.stats.get("changelog_entries", 0) + result.stats.get("attachment_files", 0)
        stats["classification_rate"] = min(classified / total_pages, 1.0)
    else:
        stats["classification_rate"] = 1.0  # vacuously true

    # 3. Module granularity: penalize extremes
    if total_modules > 0 and module_pages > 0:
        avg_pages_per_module = module_pages / total_modules
        # Ideal: 2-15 pages per module; score decays outside this range
        if 2 <= avg_pages_per_module <= 15:
            stats["module_granularity_score"] = 1.0
        elif avg_pages_per_module < 2:
            # Too few pages per module → likely over-fragmented
            stats["module_granularity_score"] = max(0.3, avg_pages_per_module / 2)
        else:
            # Too many pages per module → likely under-fragmented
            stats["module_granularity_score"] = max(0.3, 15 / avg_pages_per_module)
    elif total_modules == 0:
        stats["module_granularity_score"] = 0.0
    else:
        stats["module_granularity_score"] = 0.5  # modules exist but no pages

    # Overall score: weighted average (platform 40%, classification 30%, granularity 30%)
    stats["overall_score"] = round(
        stats["platform_accuracy"] * 0.4
        + stats["classification_rate"] * 0.3
        + stats["module_granularity_score"] * 0.3,
        4,
    )

    if stats["overall_score"] < 0.70:
        logger.warning(
            "Module extraction accuracy %.1f%% below 70%% target (platform=%.1f%%, class=%.1f%%, granularity=%.1f%%)",
            stats["overall_score"] * 100,
            stats["platform_accuracy"] * 100,
            stats["classification_rate"] * 100,
            stats["module_granularity_score"] * 100,
        )

    return stats


# ── Persistence helpers ──

def persist_module_tree(
    db: Session,
    *,
    extraction: ExtractionResult,
    release_bundle_id: int,
    project_id: int,
    source_version: str,
) -> list[int]:
    """Upsert an extracted module tree without deleting manual or historical nodes.

    Natural identities are scoped by project, bundle and source version. Lanhu
    page IDs take precedence where available; name is the fallback identity.
    Returns the top-level module and attachment IDs, whether reused or created.
    """
    from app.models.requirement_module import RequirementModule

    persisted_ids: list[int] = []

    def upsert_node(
        *,
        name: str,
        node_type: str,
        platform: str,
        parent_module_id: int | None = None,
        lanhu_page_id: str = "",
        screenshot_url: str = "",
    ) -> RequirementModule:
        identity = [
            RequirementModule.project_id == project_id,
            RequirementModule.release_bundle_id == release_bundle_id,
            RequirementModule.source_version == source_version,
            RequirementModule.node_type == node_type,
            RequirementModule.parent_module_id == parent_module_id,
        ]
        if lanhu_page_id:
            identity.append(RequirementModule.lanhu_page_id == lanhu_page_id)
        else:
            identity.append(RequirementModule.name == name)
        if node_type == "module":
            identity.append(RequirementModule.platform == platform)

        node = db.scalar(
            select(RequirementModule)
            .where(*identity)
            .order_by(RequirementModule.id)
        )
        screenshot_urls = json.dumps(
            [screenshot_url] if screenshot_url else [],
            ensure_ascii=False,
        )
        if node is None:
            node = RequirementModule(
                project_id=project_id,
                release_bundle_id=release_bundle_id,
                name=name,
                node_type=node_type,
                platform=platform,
                lanhu_page_id=lanhu_page_id,
                change_type="new",
                parent_module_id=parent_module_id,
                source_version=source_version,
                screenshot_urls=screenshot_urls,
            )
            db.add(node)
            db.flush()
            return node

        # Refresh only fields owned by automated extraction. Human-authored
        # description, interactions and visual-review flags remain untouched.
        node.name = name
        node.platform = platform
        if lanhu_page_id:
            node.lanhu_page_id = lanhu_page_id
        if screenshot_url:
            node.screenshot_urls = screenshot_urls
        return node

    for mod_node in extraction.modules:
        mod = upsert_node(
            name=mod_node.name,
            node_type=mod_node.node_type,
            platform=mod_node.platform,
        )
        persisted_ids.append(mod.id)

        for page_node in mod_node.pages:
            page = upsert_node(
                name=page_node.name,
                node_type="page",
                platform=mod_node.platform,
                lanhu_page_id=page_node.lanhu_page_id,
                parent_module_id=mod.id,
                screenshot_url=page_node.screenshot_url,
            )

            # Sub-pages
            for sub_page in page_node.child_pages:
                upsert_node(
                    name=sub_page.name,
                    node_type="page",
                    platform=mod_node.platform,
                    lanhu_page_id=sub_page.lanhu_page_id,
                    parent_module_id=page.id,
                    screenshot_url=sub_page.screenshot_url,
                )

            # Function points
            for fp in page_node.function_points:
                upsert_node(
                    name=fp.name,
                    node_type="function_point",
                    platform=mod_node.platform,
                    parent_module_id=page.id,
                )

    # Attachment nodes
    for att in extraction.attachments:
        att_node = upsert_node(
            name=att["file_name"],
            node_type="attachment",
            platform="",
            lanhu_page_id=att.get("page_id", ""),
            screenshot_url=att.get("screenshot_url", ""),
        )
        persisted_ids.append(att_node.id)

    logger.info(
        "Persisted %d module/attachment roots for bundle #%d",
        len(persisted_ids),
        release_bundle_id,
    )
    return persisted_ids

# ── Document Direct Build (Batch 118, C102-3) ──

def build_module_tree_from_document(
    db: Session,
    *,
    document_id: int,
    project_id: int,
    source_version: str = "",
) -> ExtractionResult:
    """Build a module tree directly from a requirement document.

    C102-3: 需求模块树直建 — no Lanhu evidence package required.
    Sources (in priority order):
      1. document.extraction_raw — confirmed Stage-1 AI extraction JSON
         ({"modules": [{"name", "description", "function_points": [...]}]}).
      2. document.content — markdown headings (## module / ### page /
         #### or bullets → function points).
    """
    result = ExtractionResult()
    document = db.get(RequirementDocument, document_id)
    if not document:
        result.warnings.append(f"Requirement document #{document_id} not found")
        return result

    platform_hint = document.platform or ""
    raw = (document.extraction_raw or "").strip()
    if not raw or raw == "{}":
        raw = (document.ai_raw or "").strip()

    parsed_modules: list[dict] = []
    if raw:
        try:
            payload = json.loads(raw)
        except (TypeError, ValueError):
            payload = None
        if isinstance(payload, dict) and isinstance(payload.get("modules"), list):
            parsed_modules = payload["modules"]
        elif isinstance(payload, list):
            parsed_modules = payload

    if parsed_modules:
        for idx, mod in enumerate(parsed_modules):
            if not isinstance(mod, dict) or not mod.get("name"):
                continue
            fp_list = mod.get("function_points") or []
            if not isinstance(fp_list, list):
                fp_list = []
            module = ModuleNode(
                name=str(mod.get("name")).strip(),
                platform=platform_hint or _infer_platform(str(mod.get("name") or "")),
                node_type="module",
                description=str(mod.get("description") or ""),
                sort_order=idx,
            )
            page = PageNode(
                name=f"{module.name} 功能点",
                order_index=0,
            )
            for fp in fp_list:
                if not isinstance(fp, dict):
                    continue
                page.function_points.append(FunctionPoint(
                    name=str(fp.get("title") or fp.get("name") or "").strip() or "(未命名功能点)",
                    description=str(fp.get("description") or ""),
                    category=str(fp.get("type") or ""),
                ))
            if page.function_points:
                module.pages.append(page)
            result.modules.append(module)
        result.stats = {"source": "extraction_raw", "document_id": document_id,
                        "module_count": len(result.modules)}
        return result

    # Fallback: parse markdown content headings
    content = document.content or ""
    current_module: ModuleNode | None = None
    current_page: PageNode | None = None
    for line in content.splitlines():
        stripped = line.strip()
        if stripped.startswith("## "):
            current_module = ModuleNode(
                name=stripped[3:].strip(),
                platform=platform_hint,
                node_type="module",
                sort_order=len(result.modules),
            )
            current_page = None
            result.modules.append(current_module)
        elif stripped.startswith("### ") and current_module is not None:
            current_page = PageNode(name=stripped[4:].strip(), order_index=0)
            current_module.pages.append(current_page)
        elif (stripped.startswith("#### ") or stripped.startswith("- ") or stripped.startswith("* ")) and current_page is not None:
            text = stripped.lstrip("#-* ").strip()
            if text:
                current_page.function_points.append(FunctionPoint(name=text))
        elif current_module is not None and current_page is not None and stripped:
            # plain line under a page → treat as description of last FP (if any)
            if current_page.function_points:
                current_page.function_points[-1].description += (" " if current_page.function_points[-1].description else "") + stripped
    result.stats = {"source": "content", "document_id": document_id,
                    "module_count": len(result.modules)}
    return result
