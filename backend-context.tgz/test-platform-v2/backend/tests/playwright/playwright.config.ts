import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './specs',
  timeout: 300000,          // 5min per test (match backend DEFAULT_TIMEOUT)
  retries: 0,
  reporter: [
    ['json', { outputFile: 'report.json' }],
    ['html', { open: 'never' }],
    ['list'],
  ],
  outputDir: './artifacts',
  use: {
    baseURL: process.env.BASE_URL || 'https://cameltv.com',
    // batch-170: UI 执行登录态注入（由后端 PLAYWRIGHT_STORAGE_STATE 环境变量传入）
    storageState: process.env.PLAYWRIGHT_STORAGE_STATE || undefined,
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    trace: 'retain-on-failure',
  },
  projects: [
    {
      name: 'chromium',
      use: {
        ...devices['Desktop Chrome'],
        launchOptions: {
          // 数据中心 Runner 稳定性（B114-2）：禁用 /dev/shm/GPU 与沙箱，降低页面崩溃/OOM
          args: ['--disable-dev-shm-usage', '--no-sandbox', '--disable-gpu'],
        },
      },
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },
  ],
});
