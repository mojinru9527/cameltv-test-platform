"""FastAPI application entrypoint."""
from __future__ import annotations

import logging

from contextlib import ExitStack, asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from starlette.types import ASGIApp, Receive, Scope, Send

from app.api.v1.router import api_router
from app.core.config import settings
from app.core.db import Base, engine
from app.core.exceptions import APIException, api_exception_handler

logger = logging.getLogger(__name__)

# P1-S6c: global request body limit. Content-Length is only a fast path;
# the actual byte stream is counted below so chunked requests cannot bypass it.
_MAX_BODY_BYTES = 100 * 1024 * 1024


class RequestBodyTooLarge(Exception):
    """Internal signal used to stop an ASGI request before parsing."""


class RequestSizeLimitMiddleware:
    """Reject requests once their actual or declared body grows past the cap."""

    def __init__(self, app: ASGIApp, max_bytes: int | None = None) -> None:
        self.app = app
        self.max_bytes = max_bytes if max_bytes is not None else settings.max_request_body_bytes

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or self.max_bytes <= 0:
            await self.app(scope, receive, send)
            return

        headers: dict[bytes, bytes] = {}
        for k, v in scope.get("headers", []):
            headers[k.lower()] = v
        content_length = headers.get(b"content-length")
        if content_length:
            try:
                cl = int(content_length.decode())
            except (ValueError, UnicodeDecodeError):
                cl = 0
            if cl > self.max_bytes:
                await self._reject(send)
                return

        total = 0
        response_started = False

        async def limited_receive() -> dict:
            nonlocal total
            message = await receive()
            if message.get("type") == "http.request":
                total += len(message.get("body", b""))
                if total > self.max_bytes:
                    raise RequestBodyTooLarge()
            return message

        async def tracked_send(message: dict) -> None:
            nonlocal response_started
            if message.get("type") == "http.response.start":
                response_started = True
            await send(message)

        try:
            await self.app(scope, limited_receive, tracked_send)
        except RequestBodyTooLarge:
            if response_started:
                raise
            await self._reject(send)

    async def _reject(self, send: Send) -> None:
        body = (
            b'{"code":413,"message":"'
            b'Request body exceeds configured limit",'
            b'"data":null}'
        )
        await send({
            "type": "http.response.start",
            "status": 413,
            "headers": [
                (b"content-type", b"application/json"),
                (b"content-length", str(len(body)).encode()),
            ],
        })
        await send({"type": "http.response.body", "body": body})


@asynccontextmanager
async def lifespan(application: FastAPI):
    import app.models  # noqa: F401

    # ── security validation (fail early in production) ──
    security_issues = settings.validate_security()
    if security_issues:
        logger.warning("[security] WARNING — configuration issues detected:")
        for issue in security_issues:
            logger.warning("  - %s", issue)
        if settings.environment == "production":
            raise SystemExit(
                "\n[security] FATAL — refusing to start in production with insecure configuration.\n"
                + "  Set SECRET_KEY, ADMIN_PASSWORD, TESTER_PASSWORD, and AI_API_KEY "
                + "via environment or .env file.\n"
            )

    # ── 密钥与存量密文一致性（Batch 259 / B2-5，关闭审计 S5）──
    # 未配置 SECRET_KEY 却已有密文时拒绝启动：dev 的一次性密钥会让存量密文永久解不开，
    # 且不会有任何报错——这种静默数据损坏比启动失败更贵。
    try:
        from app.core.cipher import assert_key_for_existing_ciphertext
        from app.core.db import SessionLocal

        with SessionLocal() as probe_session:
            assert_key_for_existing_ciphertext(probe_session)
    except RuntimeError:
        # 这是明确的配置错误，必须让启动失败（不要吞掉）
        logger.error("[security] SECRET_KEY 与存量密文不一致，拒绝启动")
        raise
    except Exception as exc:
        # 探测失败（例如表尚未迁移）不应阻断启动；这是刻意的宽捕获，
        # 但不要为此加 noqa 抑制：质量棘轮里 BLE001 未启用，
        # 抑制指令本身会多出一条 RUF100（unused noqa）。
        logger.warning("[security] 密钥一致性探测跳过: %s", exc)

    # ── 蓝湖证据存储落点（Batch 140/141）：确保目录存在并打印，便于确认持久卷挂载 ──
    try:
        from app.api.v1.lanhu_evidence_jobs import _storage_base

        storage_base = _storage_base()
        storage_base.mkdir(parents=True, exist_ok=True)
        # Batch 141: Railway 卷默认以 root 挂载；把目录权限放宽到 755，
        # 避免后续降权/非 root 进程读取或写入证据文件时再次 Permission denied。
        try:
            storage_base.chmod(0o755)
        except OSError:
            # 容器文件系统可能不支持 chmod 或当前用户无权修改；放权仅尽力而为，
            # 失败不阻断后续证据文件写入。
            pass
        logger.info(
            "[storage] Lanhu evidence storage base: %s （生产请用持久卷挂载，否则 Railway 重建会清空截图）",
            storage_base,
        )
    except PermissionError as exc:
        logger.warning(
            "[storage] Lanhu evidence storage init failed: %s — "
            "Railway 卷以 root 挂载而容器以非 root 运行。请在 Railway 后端服务 Variables 设置 "
            "RAILWAY_RUN_UID=0 并重新部署；或先以 root 执行 chown -R 10001:10001 /app/storage。",
            exc,
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning("[storage] Lanhu evidence storage init failed: %s", exc)

    if settings.auto_create_tables:
        Base.metadata.create_all(bind=engine)

    from app.seed import run_seed

    run_seed()

    with ExitStack() as runtime:
        application.state.consumers_healthy = lambda: True
        if settings.worker_execution_enabled:
            from app.worker import task_consumers

            application.state.consumers_healthy = runtime.enter_context(task_consumers())
        yield


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="CamelTv test platform REST API.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# P1-1/S1d: CSRF protection (validate Origin/Referer for state-changing requests)
from app.middleware.csrf import CSRFMiddleware  # noqa: E402

app.add_middleware(CSRFMiddleware)

# P1-S6c: Global request body size limit (100 MB)
app.add_middleware(RequestSizeLimitMiddleware)

# C3: Security response headers (X-Content-Type-Options, X-Frame-Options, etc.)
from app.middleware.security_headers import SecurityHeadersMiddleware  # noqa: E402

app.add_middleware(SecurityHeadersMiddleware)

# P1-2/S2c: Content-Security-Policy header (defense-in-depth against XSS)
from app.middleware.csp import CSPMiddleware  # noqa: E402

app.add_middleware(CSPMiddleware)

app.add_exception_handler(APIException, api_exception_handler)

app.include_router(api_router)


@app.get("/health", tags=["system"], summary="Health check")
def health():
    if not getattr(app.state, 'consumers_healthy', lambda: True)():
        from starlette.responses import JSONResponse

        return JSONResponse({'status': 'unhealthy', 'reason': 'task consumer stopped'}, status_code=503)
    return {"status": "ok", "version": settings.app_version}
