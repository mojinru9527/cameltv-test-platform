"""首次启动初始化数据 —— 权限/角色/管理员/测试用户/默认项目（幂等）。"""
from __future__ import annotations

import secrets as _secrets

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.security import hash_password
from app.models.project import Project, ProjectMember
from app.models.rbac import Permission, Role, RolePermission, UserRole
from app.models.user import User

# 菜单权限点：(code, name, parent_code, path, icon, sort)
_MENUS = [
    ("menu:workbench", "工作台", "", "/workbench", "DashboardOutlined", 1),
    # (P2c 入口收敛) 质量追溯已并入报告中心 Tab（/trace → /report?tab=trace 重定向），
    # 不再生成菜单；menu_service.HIDDEN_MENU_CODES 继续拦截存量库中的旧权限行。
    # ("menu:trace", "质量追溯", "", "/trace", "NodeIndexOutlined", 2),
    ("menu:requirement", "需求文档", "", "/requirement", "FileTextOutlined", 3),
    ("menu:versionmission", "版本发布包", "", "/release-bundles", "GitBranchOutlined", 4),
    # (B6-F03) 版本验收主链路唯一事实源入口（batch-216+）；testplan 数据只读归档后独立入口
    ("menu:versiontask", "版本验收任务", "", "/version-tasks", "CheckCircleOutlined", 4),
    # ── 知识中心 ──
    ("menu:knowledge", "知识中心", "", "/knowledge", "BrainCircuitOutlined", 5),
    # (c165-3 入口收敛) 知识中心四个子项与页内 Tab 完全同源（/knowledge?tab=xxx），
    # 不再生成菜单；menu_service.HIDDEN_MENU_CODES 继续拦截存量库中的旧权限行。
    # ("menu:knowledge:project", "项目知识", "menu:knowledge", "/knowledge?tab=project", "FolderOpenOutlined", 1),
    # ("menu:knowledge:platform", "平台研发", "menu:knowledge", "/knowledge?tab=platform", "SparklesOutlined", 2),
    # ("menu:knowledge:graph", "知识图谱", "menu:knowledge", "/knowledge?tab=graph", "GitBranchOutlined", 3),
    # ("menu:knowledge:artifacts", "AI审核台", "menu:knowledge", "/knowledge?tab=artifacts", "FileTextOutlined", 4),
    # ── 其余菜单 ──
    # (P2a 入口收敛) 思维导图已并入用例服务「脑图视图」Tab（/mindmap → /testcase?tab=mindmap 重定向），
    # 不再生成菜单；menu_service.HIDDEN_MENU_CODES 继续拦截存量库中的旧权限行。
    # ("menu:mindmap", "思维导图", "", "/mindmap", "ShareAltOutlined", 6),
    ("menu:testcase", "用例服务", "", "/testcase", "ProfileOutlined", 7),
    # (batch-212 入口收敛) 旧测试计划独立入口已删除（02 白名单 §3 C4：入口删除、数据只读归档）：
    # 不再生成菜单；menu_service.HIDDEN_MENU_CODES 继续拦截存量库中的旧权限行；
    # 报告中心/质量追溯/apitest 等仍只读引用 test-plan API；URL /testplan* 前端重定向 /testcase。
    # ("menu:testplan", "测试计划", "", "/testplan", "ScheduleOutlined", 8),
    ("menu:apitest", "接口测试", "", "/apitest", "ApiOutlined", 9),
    ("menu:uitest", "UI 自动化", "", "/uitest", "RobotOutlined", 10),
    # (P2b 入口收敛) Playground 已并入用例服务 Tab（/playground → /testcase?tab=playground 重定向），
    # 不再生成菜单；menu_service.HIDDEN_MENU_CODES 继续拦截存量库中的旧权限行。
    # ("menu:playground", "Playground", "", "/playground", "PlayCircleOutlined", 10),
    ("menu:schedule", "定时任务", "", "/schedule", "ClockCircleOutlined", 12),
    ("menu:system", "系统管理", "", "/system", "SettingOutlined", 14),
    ("menu:myproject", "我的项目", "", "/my-projects", "AppstoreOutlined", 15),
    ("menu:defect", "缺陷管理", "", "/defect", "BugOutlined", 16),
    ("menu:environment", "目标环境", "", "/environment", "EnvironmentOutlined", 20),
    # (batch A) AI 模型配置中心
    ("menu:ai_config", "AI 配置", "", "/ai-config", "SettingOutlined", 23),
    ("menu:lanhu_evidence", "蓝湖证据包", "", "/lanhu-evidence", "FileTextOutlined", 23),
    # (batch-336 P1) AIQE 执行中心：Run Console 入口；该权限点同时是 Console API 的门禁，
    # 无此权限 → 侧边栏不可见、/runs 路由守卫拦截、/api/v1/aiqe/* 返回 403。
    ("menu:aiqe_runs", "执行中心", "", "/runs", "PlayCircleOutlined", 24),
]

# 操作权限点（按模块分组）：(code, name, type)
_ACTIONS = [
    # 系统管理 - 用户
    ("system:user:list", "查看用户", "button"),
    ("system:user:create", "新建用户", "button"),
    ("system:user:update", "编辑用户", "button"),
    ("system:user:delete", "删除用户", "button"),
    # 系统管理 - 角色
    ("system:role:list", "查看角色", "button"),
    ("system:role:create", "新建角色", "button"),
    ("system:role:update", "编辑角色", "button"),
    ("system:role:delete", "删除角色", "button"),
    # 系统管理 - 审计
    ("system:audit:list", "查看审计日志", "button"),
    # 系统管理 - 注册邀请码（Batch 104 外放轻量模式）
    ("system:invite:manage", "管理注册邀请码", "button"),
    # 用例服务
    ("testcase:list", "查看用例", "button"),
    ("testcase:detail", "查看用例详情", "button"),
    ("testcase:create", "新建用例", "button"),
    ("testcase:update", "编辑用例", "button"),
    ("testcase:delete", "删除用例", "button"),
    ("testcase:export", "导出用例", "button"),
    # 测试计划
    ("testplan:list", "查看计划列表", "button"),
    ("testplan:detail", "查看计划详情", "button"),
    ("testplan:create", "创建计划", "button"),
    ("testplan:update", "编辑计划", "button"),
    ("testplan:delete", "删除计划", "button"),
    ("testplan:execute", "执行用例", "button"),
    # 定时任务
    ("schedule:list", "查看定时任务", "button"),
    ("schedule:create", "创建定时任务", "button"),
    ("schedule:update", "编辑定时任务", "button"),
    ("schedule:delete", "删除定时任务", "button"),
    ("schedule:trigger", "手动触发", "button"),
    # 缺陷管理
    ("defect:list", "查看缺陷", "button"),
    ("defect:detail", "查看缺陷详情", "button"),
    ("defect:create", "新建缺陷", "button"),
    ("defect:update", "编辑缺陷", "button"),
    ("defect:delete", "删除缺陷", "button"),
    # UI 自动化
    ("uitest:list", "查看UI自动化", "button"),
    ("uitest:detail", "查看UI自动化详情", "button"),
    ("uitest:create", "创建UI自动化任务", "button"),
    ("uitest:update", "编辑UI自动化任务", "button"),
    ("uitest:delete", "删除UI自动化任务", "button"),
    ("uitest:trigger", "触发UI自动化", "button"),
    ("uitest:code_execute", "执行自定义 Playwright 代码", "button"),
    ("uitest:trigger_prod", "触发生产环境UI自动化", "button"),
    # API 测试
    ("apitest:execute", "执行接口测试", "button"),
    ("apitest:view", "查看接口测试", "button"),
    ("apitest:import", "导入接口文档", "button"),
    ("apitest:generate", "生成接口用例", "button"),
    ("apitest:task", "管理执行任务", "button"),
    ("apitest:asset_manage", "管理接口资产", "button"),
    ("apitest:execute_prod", "执行生产环境接口测试", "button"),
    # 本地执行节点（Batch 258 / B1-4）：控制面只登记与调度，执行发生在本地节点
    ("execution:view", "查看执行任务与节点状态", "button"),
    ("execution:manage", "登记执行任务与回收失联租约", "button"),
    # 知识主线（Batch 260 / B3-3）：影响面查询只读；重建关联是独立动作，不复用 uitest:*
    ("impact:view", "查看影响面与未覆盖缺口", "button"),
    ("impact:manage", "重建影响图关联", "button"),
    # 项目管理
    ("project:list", "查看项目列表", "button"),
    ("project:detail", "查看项目详情", "button"),
    ("project:create", "创建项目", "button"),
    ("project:self_create", "自助创建项目", "button"),
    ("project:update", "编辑项目", "button"),
    ("project:delete", "删除项目", "button"),
    ("project:manage", "管理项目成员", "button"),
    # 需求文档
    ("requirement:upload", "上传需求文档", "button"),
    ("requirement:generate", "AI生成用例", "button"),
    ("requirement:import", "导入生成用例", "button"),
    # 版本验收任务
    ("mission:list", "查看版本测试任务", "button"),
    ("mission:detail", "查看版本测试任务详情", "button"),
    ("mission:create", "创建版本测试任务", "button"),
    ("mission:update", "编辑版本测试任务", "button"),
    ("mission:generate", "生成版本测试资产", "button"),
    # API Token 管理 (P1-6/S3)
    ("token:list", "查看 API Token", "button"),
    ("token:manage", "管理 API Token", "button"),
    # 用例评审 (C3)
    ("review:submit", "提交评审", "button"),
    ("review:approve", "审批评审", "button"),
    # 知识中心 (项目知识库)
    ("knowledge:view", "查看知识中心", "button"),
    ("knowledge:manage", "管理知识源（重解析/废弃）", "button"),
    # Wiki 知识库（收在知识中心，不新增菜单）
    ("wiki:view", "查看 Wiki 页面", "button"),
    ("wiki:manage", "导入来源、触发编译、重试任务", "button"),
    # 蓝湖证据包 OCR — 收在知识中心/需求，不新增菜单
    ("lanhu_evidence:view", "查看蓝湖证据包", "button"),
    ("lanhu_evidence:run", "创建蓝湖证据包", "button"),
    ("lanhu_evidence:review", "人工审核证据页（OCR 缺失豁免）", "button"),
    ("lanhu_evidence:import", "导入蓝湖证据包", "button"),
    # AI 配置中心（Batch A）
    ("ai_config:view", "查看 AI 配置", "button"),
    ("ai_config:manage", "管理 AI 配置", "button"),
    # batch-342（M9-3）：AIQE Workflow 审批与编辑解耦（审批默认仅管理员，经 * 放行）
    ("aiqe:workflow:approve", "审批 AIQE Workflow", "button"),
]

# 测试人员可见的菜单子集
_TESTER_ACTIONS = {
    # Batch 104 外放轻量模式：自助建项目
    "project:self_create",
    # 用例服务（B87-Q1 核心缺口）
    "testcase:list", "testcase:detail", "testcase:create", "testcase:update",
    "testcase:delete", "testcase:export",
    # 测试计划（平台简化批次：写入口已删，仅保留只读）
    "testplan:list", "testplan:detail",
    # 定时任务
    "schedule:list", "schedule:create", "schedule:update", "schedule:delete",
    "schedule:trigger",
    # 缺陷管理
    "defect:list", "defect:detail", "defect:create", "defect:update",
    # 需求文档（上传/生成/导入）
    "requirement:upload", "requirement:generate", "requirement:import",
    # 用例评审
    "review:submit", "review:approve",
    # 版本验收任务（AI 方案生成为主链路必要能力，授予 tester——F-04）
    "mission:list", "mission:detail", "mission:create", "mission:update",
    "mission:generate",
    # UI 自动化（生产触发留管理员）
    "uitest:list", "uitest:detail", "uitest:create", "uitest:update",
    "uitest:delete", "uitest:trigger",
    # 接口测试（保留；生产执行留管理员）
    "apitest:execute", "apitest:view", "apitest:import", "apitest:generate",
    "apitest:task", "apitest:asset_manage",
    # 本地执行节点（Batch 258 / B1-4）：tester 可查看节点与队列状态；登记/回收留管理员
    "execution:view",
    # 知识主线（Batch 260 / B3-3）：tester 可查询影响面；重建关联留管理员
    "impact:view",
    # 知识 / Wiki（只读视角；管理/审核留管理员）
    "knowledge:view",
    "wiki:view",
    # AI 配置中心（查看权限；管理留管理员）
    "menu:ai_config", "ai_config:view",
    # 蓝湖证据包（采集可发起；导入/审核留管理员）
    "lanhu_evidence:view", "lanhu_evidence:run",
}

# 运营只读角色（C31-3）：仅查看，无任何写操作
_VIEWER_MENUS = {
    "menu:workbench", "menu:requirement", "menu:defect",
    "menu:knowledge",  # (c165-3) menu:knowledge:* 子项已收敛进页内 Tab
    "menu:myproject",
}

_VIEWER_ACTIONS = {
    "testcase:list", "testcase:detail",
    "testplan:list", "testplan:detail",
    "defect:list", "defect:detail",
    "schedule:list",
    "knowledge:view",
    "wiki:view",
    "lanhu_evidence:view",
    "apitest:view",
    "uitest:list",
    "mission:list",
}

_TESTER_MENUS = {
    "menu:workbench", "menu:requirement", "menu:versionmission", "menu:testcase",  # (batch-212) menu:testplan 已删独立入口
    "menu:apitest", "menu:uitest", "menu:schedule",
    "menu:defect", "menu:knowledge", "menu:environment",
    # (c165-3) menu:knowledge:* 子项已收敛进页内 Tab，不再分配菜单权限
    "menu:lanhu_evidence",
    "menu:myproject",
    # (B6-F03) 版本验收主链路
    "menu:versiontask",
    # (batch-336 P1) 执行中心 / Run Console：tester 默认可见；viewer 不分配（只读角色无执行台）
    "menu:aiqe_runs",
}


def _get_or_create(db: Session, model, defaults: dict | None = None, **filters):
    obj = db.scalar(select(model).filter_by(**filters))
    if obj:
        return obj, False
    params = {**filters, **(defaults or {})}
    obj = model(**params)
    db.add(obj)
    db.flush()
    return obj, True


def run_seed() -> None:
    db: Session = None  # type: ignore[assignment]
    from app.core.db import SessionLocal

    db = SessionLocal()
    try:
        # 1) 超级权限通配点
        star, _ = _get_or_create(
            db, Permission, defaults={"name": "超级权限", "type": "api"}, code="*",
        )

        # 2) 菜单 + 操作权限点（两遍：先创建全部菜单，再回填 parent_id）
        code_to_perm: dict[str, Permission] = {}
        for code, name, _parent, path, icon, sort in _MENUS:
            perm, _ = _get_or_create(
                db, Permission,
                defaults={"name": name, "type": "menu", "path": path, "icon": icon, "sort": sort},
                code=code,
            )
            # The seed catalog is the canonical menu definition. Reconcile mutable
            # fields as well as creating missing records, otherwise renamed routes
            # stay stale forever in existing environments.
            perm.name = name
            perm.type = "menu"
            perm.path = path
            perm.icon = icon
            perm.sort = sort
            code_to_perm[code] = perm
        # 第二遍：回填 parent_id
        for code, name, parent_code, path, icon, sort in _MENUS:
            if parent_code and parent_code in code_to_perm:
                perm = code_to_perm[code]
                perm.parent_id = code_to_perm[parent_code].id
        for code, name, ptype in _ACTIONS:
            perm, _ = _get_or_create(
                db, Permission, defaults={"name": name, "type": ptype}, code=code,
            )
            code_to_perm[code] = perm

        # 3) 角色
        admin_role, _ = _get_or_create(
            db, Role, defaults={"name": "超级管理员", "data_scope": "global", "remark": "拥有全部权限"},
            code="admin",
        )
        tester_role, _ = _get_or_create(
            db, Role, defaults={"name": "测试人员", "data_scope": "project"}, code="tester",
        )
        viewer_role, _ = _get_or_create(
            db, Role, defaults={"name": "运营只读", "data_scope": "project",
                                "remark": "仅查看，无写操作（C31-3）"},
            code="viewer",
        )

        # 4) 角色-权限
        _get_or_create(db, RolePermission, role_id=admin_role.id, permission_id=star.id)
        for code in _TESTER_MENUS:
            if code in code_to_perm:
                _get_or_create(db, RolePermission, role_id=tester_role.id, permission_id=code_to_perm[code].id)
        for code in _TESTER_ACTIONS:
            if code in code_to_perm:
                _get_or_create(db, RolePermission, role_id=tester_role.id, permission_id=code_to_perm[code].id)
        for code in _VIEWER_MENUS | _VIEWER_ACTIONS:
            if code in code_to_perm:
                _get_or_create(db, RolePermission, role_id=viewer_role.id, permission_id=code_to_perm[code].id)

        # 5) 管理员用户
        admin_user = db.scalar(
            select(User).filter_by(username=settings.admin_username)
        )
        created_admin = admin_user is None
        if created_admin:
            admin_user = User(
                username=settings.admin_username,
                password=hash_password(settings.get_initial_admin_password()),
                nickname="超级管理员",
                email="admin@cameltv.local",
                status=1,
                must_change_password=settings.admin_password == "",
            )
            db.add(admin_user)
            db.flush()
        assert admin_user is not None

        # 5.5/5.6) 测试/只读演示账号（Batch 109：SEED_DEMO_USERS=false 时不创建，
        # 生产外放后避免部署时重建验收账号；角色本身仍保留）
        tester_user = None
        viewer_user = None
        created_tester = False
        created_viewer = False
        if settings.seed_demo_users:
            tester_pwd: str | None = None
            tester_user = db.scalar(
                select(User).filter_by(username=settings.tester_username)
            )
            created_tester = tester_user is None
            if created_tester:
                tester_pwd = settings.tester_password or _secrets.token_urlsafe(10)
                tester_user = User(
                    username=settings.tester_username,
                    password=hash_password(tester_pwd),
                    nickname="测试同学",
                    email="tester@cameltv.local",
                    status=1,
                )
                db.add(tester_user)
                db.flush()

            viewer_pwd: str | None = None
            viewer_user = db.scalar(
                select(User).filter_by(username=settings.viewer_username)
            )
            created_viewer = viewer_user is None
            if created_viewer:
                viewer_pwd = settings.viewer_password or _secrets.token_urlsafe(10)
                viewer_user = User(
                    username=settings.viewer_username,
                    password=hash_password(viewer_pwd),
                    nickname="运营只读",
                    email="viewer@cameltv.local",
                    status=1,
                )
                db.add(viewer_user)
                db.flush()

        # 6) 默认项目
        project, _ = _get_or_create(
            db, Project,
            defaults={"name": "CamelTv 体育平台", "description": "默认样板项目", "owner_id": admin_user.id},
            code="cameltv",
        )

        # 7) 管理员加入默认项目 + 全局管理员角色
        _get_or_create(db, ProjectMember, project_id=project.id, user_id=admin_user.id,
                       defaults={"role_id": admin_role.id})
        _get_or_create(db, UserRole, user_id=admin_user.id, role_id=admin_role.id, project_id=0)

        # 7.5) 测试/只读用户分配角色并加入默认项目（仅演示账号开启时）。
        # 两条关系必须独立幂等创建，确保全新数据库第一次启动后账号即可使用。
        if tester_user is not None:
            _get_or_create(
                db,
                UserRole,
                user_id=tester_user.id,
                role_id=tester_role.id,
                project_id=0,
            )
            _get_or_create(
                db,
                ProjectMember,
                project_id=project.id,
                user_id=tester_user.id,
                defaults={"role_id": tester_role.id},
            )
        if viewer_user is not None:
            _get_or_create(
                db,
                UserRole,
                user_id=viewer_user.id,
                role_id=viewer_role.id,
                project_id=0,
            )
            _get_or_create(
                db,
                ProjectMember,
                project_id=project.id,
                user_id=viewer_user.id,
                defaults={"role_id": viewer_role.id},
            )

        db.commit()
        if created_admin:
            print(f"[seed] 初始管理员已创建：{settings.admin_username}")
            if settings.admin_password:
                print("[seed] 管理员使用自定义密码")
            else:
                print("[seed] 管理员使用自动生成密码（见启动日志），首次登录需修改")
        if created_tester:
            print(f"[seed] 测试用户已创建：{settings.tester_username}")
            if not settings.tester_password and tester_pwd is not None:
                print(f"[seed] 测试用户自动生成密码：{tester_pwd}")
        # viewer 密码由部署环境 env VIEWER_PASSWORD 提供；不打印，避免凭据散落与 WARN 增长
        _ = viewer_user
    finally:
        db.close()
